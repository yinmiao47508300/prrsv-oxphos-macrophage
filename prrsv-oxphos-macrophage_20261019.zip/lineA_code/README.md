# Line A — PRRSV single-cell alveolar-macrophage analysis

Analysis code for the manuscript submitted to *Veterinary Research*
("decomposing PRRSV-associated mitochondrial transcript changes into
cell-intrinsic and challenged-animal-associated components").

## Environment

- Python 3.13
- numpy, scipy, matplotlib, python-docx (docx only for report generation)

## Repository layout

- `scripts/` — final analysis and figure scripts (see list below).
- `data/`   — intermediate tables and GSE304527 inputs consumed by the scripts.
- `README.md`

## Scripts and what each one does

| Script | Purpose |
|---|---|
| `_s46_qc.py` | Per-sample QC + module scoring (writes per-cell TSVs). |
| `_s51_main.py` | Two-comparison design: comparison A (viral+ vs viral-, within animal) and comparison B (infected viral- vs controls). |
| `_s52_depthmatch.py` | Depth matching within host-nUMI deciles. |
| `_s53_perorf_analyze.py` | Per-ORF threshold validation. |
| `_s56_hostdenom.py` | Host-denominator sensitivity (viral-read dilution self-check). |
| `_s57_final.py` | **Authoritative final analysis** (host denominator + host pct-mito gate + depth matching combined). |
| `_s58_thr.py` | Infection-threshold sweep (viral UMI >= 2/5/10/20/50/100). |
| `_s59_tables.py` | Supplementary Tables S1-S4. |
| `_s62_tables_S5_S6_S7.py` | Supplementary Tables S5-S7. |
| `_reanalysis_review.py` | Animal-level re-analysis of comparison B (score ~ group + dpi, n = 21 animals). |
| `_reanalysis_gse304527.py` | Sample-level module scores for GSE304527 (replicate-aware; 4 mock vs 8 infected). |
| `_s54_figs_en_v3.py` | Main Figures 1-4 (English labels). |
| `_s55_figS1.py` | Supplementary Figure S1. |
| `_s57_figS6AB.py` | Supplementary Figure S6A/B. |
| `_s58_figS7_qc_and_threshold.py` | Supplementary Figure S7. |
| `_s61_figS5A_crossvalidation.py` | Supplementary Figure S5A. |
| `_s63_figS8_GSE304527_DE.py` | Supplementary Figure S8. |

## Key definitions (for reproducibility)

- Module score = `log1p( (module UMI / host nUMI) x 1e4 )`, where
  `host nUMI = total nUMI - viral UMI` (27 viral features removed from the denominator).
- Gating: inclusive macrophage marker gate (>=1 of CD163/CSF1R/SPP1/MARCO/CD68),
  host-denominator mitochondrial fraction <= 15%.
- Comparison A: rank-biserial correlation per library, tested across the
  12 evaluable libraries by one-sample t-test.
- Comparison B: animal-level linear model `score ~ group (bystander vs control) + dpi`,
  n = 21 animals; group coefficient reported in log1p units with 95% CI;
  Benjamini-Hochberg across the eight modules.
- GSE304527: per-sample mean log2 expression module scores, Welch t-test
  (4 mock vs 8 infected samples); the gene-level log2 fold changes are descriptive
  only (genes are not independent replicates).
- GSE304527 immune signatures: per-sample mean expression of lineage-specific
  marker genes for 18 cell types (a marker-mean score, not ssGSEA).

## Data sources

- GSE247257, GSE304527, GSE22782, GSE174494 (NCBI GEO)
- MitoCarta 3.0 gene inventory
- `data/tx2gene_symbol.tsv` — gene/transcript map used by the GSE304527 re-analysis.

## Running

The scripts use absolute path constants at the top of each file (`D`, `RAW`, `PAM`,
`REF`, ...). Point them at your local copy before running. The raw GEO matrices
(GSE247257 `raw_full/*matrix.mtx.gz` and per-cell inputs) are NOT bundled here and
must be re-downloaded from GEO. Intermediate tables in `data/` are the inputs that
the later table/figure scripts consume.
