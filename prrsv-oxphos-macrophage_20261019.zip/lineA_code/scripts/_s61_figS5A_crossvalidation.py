# -*- coding: utf-8 -*-
"""Additional file 1: Figure S5A - cross-validation of candidate MitoDEG log2FC
between GSE22782 (discovery, microarray) and GSE304527 (validation, RNA-seq).

Repairs the three defects of redraw_fig4b_fig5.py::redraw_compare()
------------------------------------------------------------------
P0-1  the legend note read "ns FDR>=0.5"  ->  now "FDR >= 0.05".
P0-2  SDHC (P = 0.0115, FDR = 0.0515) carried no marker even though it is
      nominal-only significant; HSPD1 (P = 0.0426, FDR = 0.128) is in the same
      class.  Both now carry "*".  The old code derived its marker from the FDR
      list alone and therefore could not represent "P < 0.05 but FDR >= 0.05".
P0-3  the GSE22782 bars were hard-coded approximations; HSPH1 in particular was
      plotted at 0.50 whereas GSE22782_DEGs.csv gives logFC = +1.554.  All
      values now come from the source tables.

Sources
-------
GSE22782      F:/Work Buudy/GSE22782_DEGs.csv          (gene, logFC, P.Value, adj.P.Val)
GSE304527     F:/Work Buudy/GSE304527_strain_analysis.csv
              columns log2FC_all / t_pval_all / FDR_all

Run:  python _s61_figS5A_crossvalidation.py
"""
import csv
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
plt.rcParams["savefig.dpi"] = 300

MM = 1 / 25.4
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "figs_en")
os.makedirs(OUT, exist_ok=True)

CSV_22782 = r"F:/Work Buudy/GSE22782_DEGs.csv"
CSV_304527 = r"F:/Work Buudy/GSE304527_strain_analysis.csv"

GENES = ["GFM1", "MRPL2", "MRPS10", "MRPL1", "MRPL50",
         "HSPA9", "MRPL18", "HSPD1", "SDHC", "HSPH1"]

C_DISC = "#AEC7E8"      # discovery (GSE22782)
C_VALID = "#FF9896"     # validation (GSE304527)


def read_csv(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return {r["gene"].strip(): r for r in csv.DictReader(f)}


d22782 = read_csv(CSV_22782)
d304527 = read_csv(CSV_304527)

fc1, fc2, p2, fdr2 = [], [], [], []
for g in GENES:
    a, b = d22782.get(g), d304527.get(g)
    fc1.append(float(a["logFC"]) if a else np.nan)
    fc2.append(float(b["log2FC_all"]) if b else np.nan)
    p2.append(float(b["t_pval_all"]) if b else np.nan)
    fdr2.append(float(b["FDR_all"]) if b else np.nan)

print("%-9s %10s %11s %9s %9s %s" %
      ("gene", "22782 FC", "304527 FC", "P", "FDR", "marker"))
for i, g in enumerate(GENES):
    m = ""
    if not np.isnan(fdr2[i]):
        m = "**" if fdr2[i] < 0.05 else ("*" if p2[i] < 0.05 else "")
        if not m:
            m = "(ns)"
    print("%-9s %10.4f %11.4f %9.4f %9.4f %s"
          % (g, fc1[i], fc2[i] if not np.isnan(fc2[i]) else float("nan"),
             p2[i] if not np.isnan(p2[i]) else float("nan"),
             fdr2[i] if not np.isnan(fdr2[i]) else float("nan"), m))

# ---- draw -----------------------------------------------------------------
fig, ax = plt.subplots(figsize=(174 * MM, 94 * MM))
x = np.arange(len(GENES))
w = 0.38

b1 = ax.bar(x - w / 2, np.nan_to_num(fc1), w, label="GSE22782 (microarray, 3 vs 3)",
            color=C_DISC, edgecolor="#34495E", linewidth=0.6)
b2 = ax.bar(x + w / 2, np.nan_to_num(fc2), w, label="GSE304527 (RNA-seq, 4 vs 8)",
            color=C_VALID, edgecolor="#34495E", linewidth=0.6)

for i in range(len(GENES)):
    if np.isnan(fc2[i]):
        ax.text(i + w / 2, 0.03, "n.d.", ha="center", va="bottom",
                fontsize=7.4, style="italic", color="#7B7D7D", rotation=90)
        continue
    mark = "**" if fdr2[i] < 0.05 else ("*" if p2[i] < 0.05 else None)
    if mark is None:
        continue
    v = fc2[i]
    off = 0.055 if v >= 0 else -0.055
    ax.text(i + w / 2, v + off, mark, ha="center",
            va="bottom" if v >= 0 else "top",
            fontsize=11, color="#B03A2E", fontweight="bold")

# HSPH1 discovery bar is by far the tallest; annotate it so the scale reads
ia = GENES.index("HSPH1")
ax.annotate("%.2f" % fc1[ia], xy=(ia - w / 2, fc1[ia]), xytext=(ia - w / 2, fc1[ia] + 0.10),
            ha="center", fontsize=7.4, color="#34495E")

ax.axhline(0, color="black", linewidth=0.7)
ax.set_xticks(x)
ax.set_xticklabels(GENES, fontsize=8.6)
ax.set_ylabel("log$_2$ fold change (PRRSV vs mock)", fontsize=8.8)
ax.set_ylim(-0.75, 1.80)
ax.tick_params(axis="y", labelsize=8.0, width=0.7, length=2.6)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)
for sp in ("left", "bottom"):
    ax.spines[sp].set_linewidth(0.8)
ax.legend(loc="upper left", frameon=False, fontsize=8.2)
ax.set_title("Cross-validation of candidate MitoDEG log$_2$ fold changes between "
             "GSE22782 and GSE304527", fontsize=9.0, pad=16)
ax.text(0.0, 1.035,
        "GSE304527:  ** FDR < 0.05;  * P < 0.05 but FDR $\\geq$ 0.05;  "
        "no marker P $\\geq$ 0.05;  n.d. not detected.",
        transform=ax.transAxes, fontsize=7.0, color="#2C3E50", va="bottom")
fig.tight_layout(pad=0.5)

stem = "FigureS5A_compare_clean"
fig.savefig(os.path.join(OUT, stem + ".png"), dpi=300)
try:
    fig.savefig(os.path.join(OUT, stem + ".tiff"), dpi=300,
                pil_kwargs={"compression": "tiff_lzw"})
    print("tiff ok")
except Exception as e:                                     # pragma: no cover
    print("TIFF skipped:", e)
plt.close(fig)
print("written to", OUT)
