# -*- coding: utf-8 -*-
"""Additional file 1: Figure S6A (immune signature scores) and S6B (SDHC/MRPL2
versus immune signature correlations).

Offline rewrite of redraw_immune_GSE304527.py.

Changes relative to the original script
---------------------------------------
1. No pandas, no network.  Transcript -> symbol mapping now comes from the
   local file 线A_分析/ref/tx2gene_symbol.tsv  (Ensembl 113 Sscrofa11.1), which
   removes the Ensembl BioMart HTTP dependency.
2. S6A significance is now coded by the Benjamini-Hochberg adjusted q value
   across the 18 signatures, not by the raw Mann-Whitney P value.  Only
   Macrophage_M1, NK_cell and Treg survive q < 0.05; DC and cDC1 are shown as
   nominal only, matching the Results text.
3. S6B: the spurious SDHC-DC asterisk is gone.  Recomputing from the same
   matrix gives rho = -0.559, P = 0.0586 for that cell, so it never reached
   P < 0.05; the original figure carried it as a rendering error.
4. Journal output: 300 dpi, Arial/DejaVu Sans, PNG + TIFF (LZW).  All
   coordinates in the code below are millimetres.

Run:  python _s57_figS6AB.py
"""
import csv
import gzip
import os

import numpy as np
from scipy.stats import spearmanr, mannwhitneyu
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.patches as mpatches

# ---------------------------------------------------------------------------
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["savefig.dpi"] = 300

MM = 1 / 25.4
HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(HERE, "ref", "tx2gene_symbol.tsv")
PAM = r"F:/Work Buudy/GSE304527_PAM.csv.gz"
OUT = os.path.join(HERE, "figs_en")
os.makedirs(OUT, exist_ok=True)

MOCK = ["PAM_Mock_3", "PAM_Mock_4", "PAM_Mock_6", "PAM_Mock_7"]
PRRSV = ["PAM_134_3", "PAM_134_4", "PAM_134_6", "PAM_134_7",
         "PAM_174_3", "PAM_174_4", "PAM_174_6", "PAM_174_7"]
ALL = MOCK + PRRSV

C_MOCK = "#2E8B74"     # green = mock
C_PRRSV = "#D9635C"    # red  = PRRSV
INK = "#2C3E50"

# ---------------------------------------------------------------------------
# 1. marker gene sets (unchanged from the original analysis)
# ---------------------------------------------------------------------------
IMMUNE_SETS = {
    "T_cell":       ["CD3D", "CD3E", "CD3G", "CD28", "LCK", "CD4", "CD8A", "CD8B"],
    "CD8_T":        ["CD8A", "CD8B", "GZMB", "PRF1", "NKG7", "CCL5", "GZMA"],
    "Treg":         ["FOXP3", "IL10", "TGFB1", "CTLA4", "IKZF2", "TNFRSF18"],
    "B_cell":       ["CD19", "MS4A1", "CD79A", "CD79B", "CD22", "BLK", "BANK1", "PAX5"],
    "NK_cell":      ["NKG7", "KLRD1", "KLRK1", "KLRC1", "NCR1", "NCR3", "FCGR3A"],
    "Monocyte":     ["CD14", "LYZ", "CSF1R", "FCGR3A", "CCR2", "S100A8", "S100A9"],
    "Macrophage_M1": ["TNF", "IL1B", "IL6", "CXCL8", "CXCL10", "CCL2", "CCL3", "NOS2"],
    "Macrophage_M2": ["CD163", "MRC1", "MSR1", "ARG1"],
    "DC":           ["CD1C", "CLEC10A", "ITGAX", "CD80", "CD86", "HLA-DRA", "HLA-DRB1"],
    "pDC":          ["IRF7", "TLR7", "TLR9", "CLEC4C", "LILRA4"],
    "cDC1":         ["XCR1", "BATF3", "IRF8", "CLEC9A"],
    "cDC2":         ["CD1C", "CLEC10A", "FCER1A", "IRF4"],
    "Neutrophil":   ["CXCR2", "CXCR1", "S100A8", "S100A9", "CSF3R", "FCGR3B", "CXCL8"],
    "Eosinophil":   ["SIGLEC8", "CCR3", "IL5RA", "PRG2", "RNASE2", "RNASE3"],
    "Plasma_cell":  ["PRDM1", "XBP1", "IRF4", "CD38", "SDC1", "TNFRSF17"],
    "Th1":          ["TBX21", "IFNG", "IL12RB2", "STAT4"],
    "Th2":          ["GATA3", "IL4", "IL5", "IL13", "STAT6"],
    "Th17":         ["RORC", "IL17A", "IL17F", "IL23R", "CCR6"],
}
LABEL = {"T_cell": "T cell", "CD8_T": "CD8 T", "Treg": "Treg", "B_cell": "B cell",
         "NK_cell": "NK cell", "Monocyte": "Monocyte",
         "Macrophage_M1": "Macrophage M1", "Macrophage_M2": "Macrophage M2",
         "DC": "DC", "pDC": "pDC", "cDC1": "cDC1", "cDC2": "cDC2",
         "Neutrophil": "Neutrophil", "Eosinophil": "Eosinophil",
         "Plasma_cell": "Plasma cell", "Th1": "Th1", "Th2": "Th2", "Th17": "Th17"}

# ---------------------------------------------------------------------------
# 2. local transcript -> symbol map
# ---------------------------------------------------------------------------
want = set([s for v in IMMUNE_SETS.values() for s in v]) | {"SDHC", "MRPL2"}
sym2tx = {}
with open(REF, encoding="utf-8", errors="replace") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        g = (r["gene_name"] or "").strip()
        if g in want:
            sym2tx.setdefault(g, []).append(r["transcript_id"])
missing = sorted(want - set(sym2tx))
if missing:
    print("WARNING  symbols absent from local map:", missing)

# ---------------------------------------------------------------------------
# 3. expression matrix -> gene-level values -> marker-mean signature scores
# ---------------------------------------------------------------------------
with gzip.open(PAM, "rt", encoding="utf-8", errors="replace") as f:
    rd = csv.reader(f, delimiter="\t")
    header = next(rd)
    rows = {r[0]: np.array([float(x) for x in r[1:]], dtype=float)
            for r in rd if r}
cols = header[1:]
idx = [cols.index(c) for c in ALL]


def gene_expr(sym):
    tx = [rows[t] for t in sym2tx.get(sym, []) if t in rows]
    return np.mean(tx, axis=0) if tx else None


scores = {}
for ct, markers in IMMUNE_SETS.items():
    vals = [gene_expr(m)[idx] for m in markers if gene_expr(m) is not None]
    if vals:
        scores[ct] = np.mean(vals, axis=0)
print("signature scores computed for %d / %d cell types"
      % (len(scores), len(IMMUNE_SETS)))

mi = [ALL.index(c) for c in MOCK]
pi = [ALL.index(c) for c in PRRSV]

# ---------------------------------------------------------------------------
# 4. S6A statistics: Mann-Whitney U + Benjamini-Hochberg over the 18 signatures
# ---------------------------------------------------------------------------
stats = []
for ct in scores:
    v = scores[ct]
    u, p = mannwhitneyu(v[pi], v[mi], alternative="two-sided")
    stats.append(dict(ct=ct, p=p, q=None, mock=v[mi], prrsv=v[pi],
                      mock_mean=float(v[mi].mean()), prrsv_mean=float(v[pi].mean())))
order = sorted(range(len(stats)), key=lambda i: stats[i]["p"])
n = len(stats)
running = 1.0
for k in range(n - 1, -1, -1):
    i = order[k]
    running = min(running, stats[i]["p"] * n / (k + 1))
    stats[i]["q"] = running

print("\n=== Figure S6A  GSE304527 immune signature scores (PRRSV vs mock) ===")
print("%-16s %10s %10s %10s %10s" % ("cell_type", "P", "q(BH)", "mock", "PRRSV"))
for i in order:
    s = stats[i]
    tag = "  q<0.05" if s["q"] < 0.05 else ("  nominal only" if s["p"] < 0.05 else "")
    print("%-16s %10.4f %10.4f %10.2f %10.2f%s"
          % (s["ct"], s["p"], s["q"], s["mock_mean"], s["prrsv_mean"], tag))

# the five signatures that reach nominal significance, in the order used before
shown = [s for i in order for s in [stats[i]] if s["p"] < 0.05]


def star(q):
    return "**" if q < 0.01 else ("*" if q < 0.05 else None)


# ---- draw S6A -------------------------------------------------------------
figA, ax = plt.subplots(figsize=(170 * MM, 92 * MM))
width = 0.30
for i, s in enumerate(shown):
    bp = ax.boxplot([s["mock"], s["prrsv"]],
                    positions=[i - width / 2 - 0.015, i + width / 2 + 0.015],
                    widths=width, showfliers=False, patch_artist=True,
                    medianprops=dict(color="black", lw=1.1, zorder=6),
                    whiskerprops=dict(color="#4D5656", lw=0.8),
                    capprops=dict(color="#4D5656", lw=0.8))
    for patch, c in zip(bp["boxes"], [C_MOCK, C_PRRSV]):
        patch.set_facecolor(c)
        patch.set_alpha(0.85)
        patch.set_edgecolor("#34495E")
        patch.set_linewidth(0.6)
    for j, (vals, xa) in enumerate([(s["mock"], i - width / 2 - 0.015),
                                    (s["prrsv"], i + width / 2 + 0.015)]):
        jit = np.linspace(-0.055, 0.055, len(vals))
        ax.scatter(xa + jit, vals, s=5.5, color="#1B2631", zorder=5,
                   linewidths=0, alpha=0.85)

    ymax = max(s["mock"].max(), s["prrsv"].max())
    st = star(s["q"])
    if st is not None:
        ax.text(i, ymax * 1.045, st, ha="center", va="bottom",
                fontsize=10.5, fontweight="bold", color="black")
    else:
        ax.text(i, ymax * 1.05, "n.s.", ha="center", va="bottom",
                fontsize=7.2, color="#7B7D7D", style="italic")

ax.set_xticks(range(len(shown)))
ax.set_xticklabels([LABEL[s["ct"]] for s in shown], fontsize=8.4)
ax.set_ylabel("Immune signature score (marker mean)", fontsize=8.6)
ax.set_ylim(2.6, 11.6)
ax.tick_params(axis="y", labelsize=8.0, width=0.7, length=2.6)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)
for sp in ("left", "bottom"):
    ax.spines[sp].set_linewidth(0.8)
ax.set_title("Population-level immune signature scores, GSE304527 PAMs "
             "(4 mock vs 8 PRRSV-2-infected)", fontsize=8.8, pad=7)
ax.legend(handles=[mpatches.Patch(color=C_MOCK, alpha=0.85, label="Mock (n = 4)"),
                   mpatches.Patch(color=C_PRRSV, alpha=0.85, label="PRRSV (n = 8)")],
          loc="upper left", frameon=False, fontsize=8.0,
          bbox_to_anchor=(0.995, 1.015))

figA.tight_layout(pad=0.5)

# ---------------------------------------------------------------------------
# 5. S6B statistics: Spearman vs SDHC and MRPL2
# ---------------------------------------------------------------------------
core = {g: gene_expr(g)[idx] for g in ("SDHC", "MRPL2")}
corder = list(IMMUNE_SETS.keys())
R = np.zeros((2, len(corder)))
P = np.zeros((2, len(corder)))
for a, g in enumerate(("SDHC", "MRPL2")):
    for b, ct in enumerate(corder):
        R[a, b], P[a, b] = spearmanr(core[g], scores[ct])

print("\n=== Figure S6B  Spearman rho (n = 12) ===")
print("%-16s %18s %18s" % ("cell_type", "SDHC  rho / P", "MRPL2 rho / P"))
bad = []
for b, ct in enumerate(corder):
    print("%-16s %8.3f %9.4f %8.3f %9.4f"
          % (ct, R[0, b], P[0, b], R[1, b], P[1, b]))
    for a in (0, 1):
        if P[a, b] < 0.05 and P[a, b] > 0.045:
            bad.append((("SDHC", "MRPL2")[a], ct, R[a, b], P[a, b]))
if bad:
    print("\nborderline (>0.045):", bad)

# ---- draw S6B -------------------------------------------------------------
figB, axB = plt.subplots(figsize=(180 * MM, 66 * MM))
cmap = LinearSegmentedColormap.from_list("rb", ["#1D9E75", "#FFFFFF", "#E24B4A"])
im = axB.imshow(R, aspect="auto", cmap=cmap, vmin=-1, vmax=1)
axB.set_xticks(range(len(corder)))
axB.set_xticklabels([LABEL[c] for c in corder], rotation=45, ha="right", fontsize=7.0)
axB.set_yticks([0, 1])
axB.set_yticklabels(["SDHC", "MRPL2"], fontsize=9, fontweight="bold")
axB.set_xticks(np.arange(-0.5, len(corder), 1), minor=True)
axB.set_yticks(np.arange(-0.5, 2, 1), minor=True)
axB.grid(which="minor", color="white", lw=1.1)
axB.tick_params(which="minor", length=0)
axB.tick_params(which="major", length=0)
for a in range(2):
    for b in range(len(corder)):
        axB.text(b, a - 0.16, "%.2f" % R[a, b], ha="center", va="center",
                 fontsize=6.0, color="#333333")
        if P[a, b] < 0.05:
            axB.text(b, a + 0.22, "*", ha="center", va="center",
                     fontsize=10, fontweight="bold", color="black")
axB.set_title("SDHC / MRPL2 expression versus immune signature scores "
              "(GSE304527 PAMs, Spearman)", fontsize=8.6, pad=6)
cb = figB.colorbar(im, ax=axB, fraction=0.022, pad=0.012)
cb.set_label("Spearman rho", fontsize=7.6)
cb.ax.tick_params(labelsize=6.8, length=2)
for sp in axB.spines.values():
    sp.set_linewidth(0.8)
axB.text(0.0, 1.135,
         r"$\ast$ $P$ < 0.05 (uncorrected); $n$ = 12 samples",
         transform=axB.transAxes, fontsize=6.6, color=INK, va="bottom")
figB.tight_layout(pad=0.5)

# ---------------------------------------------------------------------------
def save(fig, stem):
    ok = True
    fig.savefig(os.path.join(OUT, stem + ".png"), dpi=300)
    try:
        fig.savefig(os.path.join(OUT, stem + ".tiff"), dpi=300,
                    pil_kwargs={"compression": "tiff_lzw"})
    except Exception as e:                                  # pragma: no cover
        ok = False
        print("TIFF skipped:", e)
    plt.close(fig)
    return ok


print("\nS6A tiff=%s  S6B tiff=%s" % (save(figA, "FigureS6A_marker_immune"),
                                     save(figB, "FigureS6B_corr_SDHC_MRPL2")))
print("written to", OUT)
