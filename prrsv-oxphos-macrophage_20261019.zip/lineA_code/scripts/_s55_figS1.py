# -*- coding: utf-8 -*-
"""Additional file 1: Figure S1 (Study design).

Drawn directly from the drawing specification (_figS1_spec.md).
Canvas 180 x 150 mm, Arial (falls back to DejaVu Sans), 300 dpi.
All coordinates are in millimetres.

Panel A  y = 78 .. 150 mm  (four datasets, resolution + assigned role)
Panel B  y =  0 ..  72 mm  (the two orthogonal comparisons within GSE247257)
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, FancyArrowPatch

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["savefig.dpi"] = 300

MM = 1 / 25.4
W, H = 180.0, 150.0
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figs_en")
os.makedirs(OUT, exist_ok=True)

# ---- palette (spec section 7; nothing outside this list) -------------------
C_PRIMARY = "#C0392B"   # primary dataset / viral positive
C_VALID   = "#2471A3"   # bulk validation / paracrine arrow
C_DISC    = "#E67E22"   # bulk discovery
C_ANCHOR  = "#7F8C8D"   # in vivo anchor
GREY_DOT  = "#D5D8DC"   # viral negative bystander
GREY_EDGE = "#7F8C8D"
GRID_EDGE = "#5D6D7E"
INF_FILL  = "#FADBD8"
INF_EDGE  = "#922B21"
CTL_FILL  = "#F2F3F4"
STRIP_BG  = "#F4F6F7"
INK       = "#2C3E50"
Q1        = "#1B4F72"
Q3        = "#935116"
Q4        = "#7D3C98"

fig = plt.figure(figsize=(W * MM, H * MM))

axA = fig.add_axes([0, 0.48, 1, 0.52])
axA.set_xlim(0, 180); axA.set_ylim(0, 78); axA.axis("off")

axB = fig.add_axes([0, 0.00, 1, 0.48])
axB.set_xlim(0, 180); axB.set_ylim(0, 72); axB.axis("off")


def T(ax, x, y, s, size=7, ha="center", va="top", color="#000000",
      w="normal", st="normal", rot=0):
    ax.text(x, y, s, fontsize=size, ha=ha, va=va, color=color,
            fontweight=w, fontstyle=st, rotation=rot)


def panel_tag(ax, x, y, tag, title):
    T(ax, x, y, tag, 9, "left", "top", "#000000", "bold")
    T(ax, x + 4.6, y, "| " + title, 9, "left", "top", "#000000", "bold")


# ===========================================================================
# Panel A - four public datasets
# ===========================================================================
panel_tag(axA, 4, 77.5, "A", "Four public datasets, their resolution and their assigned roles")

DATASETS = [
    dict(id="GSE247257", role="PRIMARY DATASET", rc=C_PRIMARY, icon="scrna",
         lines=["Single-cell RNA-seq",
                "Pig BALF cells",
                "36 libraries: uninfected",
                "control and JA142 at 3, 7,",
                "14 and 21 dpi; JB15-N-M8-",
                "GN and JB15-N-PJ10-GN at",
                "3 and 7 dpi; 3 animals/group"],
         note=["Only dataset with PRRSV open",
               "reading frames annotated.",
               "Carries all cell-level infection",
               "calling and the two-comparison",
               "analysis."]),
    dict(id="GSE304527", role="BULK VALIDATION", rc=C_VALID, icon="bulk",
         lines=["Bulk RNA-seq",
                "Primary porcine alveolar",
                "macrophages (PAMs)",
                "4 mock vs 8 PRRSV-2-",
                "infected (NC134, n = 4;",
                "NC174, n = 4)"],
         note=["Tests whether the",
               "mitochondrial signature is",
               "directionally reproducible",
               "at the population level."]),
    dict(id="GSE22782", role="BULK DISCOVERY", rc=C_DISC, icon="array",
         lines=["Microarray (Affymetrix",
                "Porcine Genome Array,",
                "GPL3533)",
                "PAMs, Tongcheng piglets",
                "3 uninfected (0 dpi) vs",
                "3 infected (5 dpi)"],
         note=["Exploratory only. Defines",
               "candidate MitoDEGs and",
               "cross-platform direction;",
               "no confirmatory inference."]),
    dict(id="GSE174494", role="IN VIVO ANCHOR", rc=C_ANCHOR, icon="sorted",
         lines=["Bulk RNA-seq",
                "Sorted EGFP+, EGFP- and",
                "CD163+ populations",
                "3 samples each, paired",
                "animals; no mock control"],
         note=["The only bulk resource",
               "separating truly infected from",
               "bystander cells in vivo.",
               "Anchors the direction of",
               "the contrast only."]),
]

BAR_Y = 70.5           # top colour bar bottom edge
ICON_CY = 63.5         # icon centre
ID_Y = 55.0
LINE_Y0, LINE_DY = 51.5, 2.9
ROLE_Y0, ROLE_H = 21.0, 7.0
NOTE_Y0, NOTE_DY = 19.5, 2.5


def draw_icon(ax, cx, cy, kind):
    """12 x 12 mm line icons, one per sequencing resolution."""
    if kind == "scrna":                      # 5 x 5 dot grid, 2 red
        red = {(1, 3), (3, 1)}
        for i in range(5):
            for j in range(5):
                x = cx + (i - 2) * 2.6
                y = cy + (j - 2) * 2.6
                c = C_PRIMARY if (i, j) in red else GREY_DOT
                ax.add_patch(Circle((x, y), 1.0, facecolor=c,
                                    edgecolor=GREY_EDGE, lw=0.45))
    elif kind == "bulk":                     # 3 lanes + joined peak line
        xs = [cx - 4.6, cx, cx + 4.6]
        hs = [3.6, 6.4, 4.8]
        for x, h in zip(xs, hs):
            ax.add_patch(Rectangle((x - 1.7, cy - 5.0), 3.4, h,
                                   facecolor=GREY_DOT, edgecolor=GRID_EDGE, lw=0.5))
        ax.plot(xs, [cy - 5.0 + h for h in hs], "-", color=C_VALID, lw=1.0)
    elif kind == "array":                    # 4 x 4 probe grid
        for i in range(4):
            for j in range(4):
                ax.add_patch(Rectangle((cx - 5.1 + i * 2.7, cy - 5.1 + j * 2.7),
                                       2.2, 2.2, facecolor="#E8E8E8",
                                       edgecolor=GREY_EDGE, lw=0.45))
    elif kind == "sorted":                   # funnel splitting into 3
        ax.add_patch(Polygon([[cx - 5.6, cy + 5.2], [cx + 5.6, cy + 5.2],
                              [cx + 1.8, cy - 0.6], [cx - 1.8, cy - 0.6]],
                             closed=True, facecolor=CTL_FILL,
                             edgecolor=GRID_EDGE, lw=0.6))
        for dx in (-4.6, 0, 4.6):
            ax.plot([cx, cx + dx], [cy - 0.6, cy - 3.9], "-",
                    color=GREY_EDGE, lw=0.8)
            ax.add_patch(Circle((cx + dx, cy - 5.0), 0.95, facecolor=GREY_DOT,
                                edgecolor=GREY_EDGE, lw=0.45))


for i, d in enumerate(DATASETS):
    x0 = 4 + i * 44
    cx = x0 + 20
    # (1) role colour bar
    axA.add_patch(Rectangle((x0, BAR_Y), 40, 3.5, facecolor=d["rc"], edgecolor="none"))
    # (2) resolution icon
    draw_icon(axA, cx, ICON_CY, d["icon"])
    # (3) dataset ID
    T(axA, cx, ID_Y, d["id"], 8, "center", "top", "#000000", "bold")
    # (4) platform and samples
    y = LINE_Y0
    for ln in d["lines"]:
        T(axA, cx, y, ln, 6.8, "center", "top")
        y -= LINE_DY
    # (5) role block
    axA.add_patch(Rectangle((x0 + 1.5, ROLE_Y0), 37, ROLE_H,
                            facecolor=d["rc"], edgecolor="none"))
    T(axA, cx, ROLE_Y0 + ROLE_H / 2.0, d["role"], 7, "center", "center",
      "#FFFFFF", "bold")
    # role footnote
    y = NOTE_Y0
    for ln in d["note"]:
        T(axA, cx, y, ln, 6.3, "center", "top", "#566573")
        y -= NOTE_DY

T(axA, 90, 5.6,
  "Only GSE247257 annotates the PRRSV open reading frames "
  "\u2192 all cell-level infection calling is made there.",
  7, "center", "top", "#000000", "bold")

# ===========================================================================
# Panel B - two orthogonal comparisons
# ===========================================================================
panel_tag(axB, 4, 71.0, "B", "Two orthogonal comparisons within GSE247257")

# --- rectangle L : infected library ---------------------------------------
LX0, LX1, RY0, RY1 = 5.0, 50.0, 28.0, 58.0
axB.add_patch(Rectangle((LX0, RY0), LX1 - LX0, RY1 - RY0,
                        facecolor=INF_FILL, edgecolor=INF_EDGE, lw=1.0))
T(axB, (LX0 + LX1) / 2, 56.2, "Infected library", 7, "center", "center",
  INF_EDGE, "bold")
T(axB, (LX0 + LX1) / 2, 53.9, "(n = 24 libraries)", 6.5, "center", "center", INF_EDGE)

RED_POS = {(1, 4), (3, 1), (5, 4), (6, 2), (8, 3), (2, 1)}
for i in range(10):
    for j in range(6):
        x = 8.2 + i * 4.2
        y = 50.0 - j * 2.4
        c = C_PRIMARY if (i, j) in RED_POS else GREY_DOT
        axB.add_patch(Circle((x, y), 1.05, facecolor=c, edgecolor=GREY_EDGE,
                             lw=0.0 if c == C_PRIMARY else 0.35, zorder=3))

# arrow A, inside rectangle L
axB.add_patch(FancyArrowPatch((15.0, 34.0), (40.0, 34.0), arrowstyle="<|-|>",
                              mutation_scale=7, lw=1.25, color=C_PRIMARY, zorder=4))
T(axB, 27.5, 25.4, "Comparison A \u2014 intrinsic", 8, "center", "top",
  C_PRIMARY, "bold")
T(axB, 27.5, 22.5, "viral+ vs viral\u2212 within the same library", 6.7,
  "center", "top", C_PRIMARY)
T(axB, 27.5, 20.2, "12 evaluable libraries", 6.7, "center", "top", C_PRIMARY)

# --- rectangle R : age-matched uninfected control -------------------------
RX0, RX1 = 62.0, 107.0
axB.add_patch(Rectangle((RX0, RY0), RX1 - RX0, RY1 - RY0,
                        facecolor=CTL_FILL, edgecolor=GREY_EDGE, lw=1.0))
T(axB, (RX0 + RX1) / 2, 56.2, "Age-matched uninfected control", 7, "center",
  "center", GRID_EDGE, "bold")
T(axB, (RX0 + RX1) / 2, 53.9, "(3 animals per time point)", 6.5, "center",
  "center", GRID_EDGE)
for i in range(9):
    for j in range(5):
        axB.add_patch(Circle((64.4 + i * 4.6, 50.4 - j * 2.6), 1.05,
                             facecolor=GREY_DOT, edgecolor=GREY_EDGE,
                             lw=0.35, zorder=3))

# --- arrow B : paracrine, spanning the gap --------------------------------
axB.add_patch(FancyArrowPatch((50.6, 43.0), (61.4, 43.0), arrowstyle="<|-|>",
                              mutation_scale=7, lw=1.25, color=C_VALID, zorder=5))
axB.plot([56.0, 56.0], [59.8, 44.6], "-", color=C_VALID, lw=0.5, zorder=2)
T(axB, 56.0, 66.6, "Comparison B \u2014 microenvironment-associated", 8, "center", "top",
  C_VALID, "bold")
T(axB, 56.0, 63.6, "bystanders in infected libraries", 6.7, "center", "top", C_VALID)
T(axB, 56.0, 61.2, "vs age-matched controls; 12 libraries", 6.7, "center", "top", C_VALID)

# --- dot legend -----------------------------------------------------------
axB.add_patch(Circle((7.0, 15.0), 1.05, facecolor=C_PRIMARY, edgecolor="none"))
T(axB, 9.2, 15.0, "viral+ (\u226510 viral UMI)", 6.8, "left", "center")
axB.add_patch(Circle((48.0, 15.0), 1.05, facecolor=GREY_DOT,
                     edgecolor=GREY_EDGE, lw=0.35))
T(axB, 50.2, 15.0, "viral\u2212 bystander (0 viral UMI)", 6.8, "left", "center")

# --- full-width italic note ----------------------------------------------
T(axB, 4, 12.0,
  "Both comparisons are made within one dataset, so individual, batch and "
  "library effects are held constant.",
  6.0, "left", "top", "#000000", "normal", "italic")

# --- right zone : four-quadrant frame ------------------------------------
QX0, QX1, QY0, QY1 = 116.0, 176.0, 17.0, 67.0
QCX, QCY = (QX0 + QX1) / 2.0, (QY0 + QY1) / 2.0
axB.add_patch(Rectangle((QX0, QY0), QX1 - QX0, QY1 - QY0,
                        facecolor="#FFFFFF", edgecolor="#000000", lw=0.75))
axB.plot([QX0, QX1], [QCY, QCY], "-", color="#000000", lw=0.75)
axB.plot([QCX, QCX], [QY0, QY1], "-", color="#000000", lw=0.75)

T(axB, QCX, 15.0, "Comparison A (intrinsic) mean module r", 7, "center", "top")
T(axB, 113.6, QCY, "Comparison B (microenvironment-associated) mean module r", 7, "center",
  "center", rot=90)

# upper-right  (A > 0, B > 0)
T(axB, QCX + 2.0, 63.5, "Up in both", 7, "left", "top", Q1, "bold")
T(axB, QCX + 2.0, 57.8, "(intrinsic up,", 6.2, "left", "top", Q1)
T(axB, QCX + 2.0, 55.5, "microenvironment up)", 6.2, "left", "top", Q1)
# upper-left  (A < 0, B > 0)
T(axB, QX0 + 2.0, 63.5, "Divergent", 7, "left", "top", Q1, "bold")
T(axB, QX0 + 2.0, 57.8, "(intrinsic down,", 6.2, "left", "top", Q1)
T(axB, QX0 + 2.0, 55.5, "microenvironment up)", 6.2, "left", "top", Q1)
# lower-left  (A < 0, B < 0)
T(axB, QX0 + 2.0, 38.5, "Dual-component", 7, "left", "top", Q3, "bold")
T(axB, QX0 + 2.0, 35.5, "(both down)", 7, "left", "top", Q3, "bold")
T(axB, QX0 + 2.0, 32.3, "\u2190 main conclusion", 6.2, "left", "top", Q3, "bold")
# lower-right  (A > 0, B < 0)
T(axB, QCX + 2.0, 38.5, "Divergent", 7, "left", "top", Q4, "bold")
T(axB, QCX + 2.0, 35.5, "(intrinsic up,", 6.2, "left", "top", Q4)
T(axB, QCX + 2.0, 33.2, "microenvironment down)", 6.2, "left", "top", Q4)

T(axB, QX1 - 1.5, 18.8, "cf. Figure 3", 6.2, "right", "bottom", "#808B96")

# --- bottom strip ---------------------------------------------------------
axB.add_patch(Rectangle((4, 1.0), 172, 8.0, facecolor=STRIP_BG, edgecolor="none"))
T(axB, 6.5, 7.6, "Infection threshold: \u226510 viral UMI; swept at 2, 5, 10, 20, "
  "50 and 100 viral UMI", 6.8, "left", "top", INK)
T(axB, 6.5, 4.6, "Depth matching: within-library host-nUMI deciles, weighted by "
  "the number of viral-positive cells", 6.8, "left", "top", INK)

# ===========================================================================
png = os.path.join(OUT, "FigureS1_study_design.png")
pdf = os.path.join(OUT, "FigureS1_study_design.pdf")
fig.savefig(png, dpi=300)
fig.savefig(pdf)
tif_ok = True
try:
    fig.savefig(os.path.join(OUT, "FigureS1_study_design.tiff"), dpi=300,
                pil_kwargs={"compression": "tiff_lzw"})
except Exception as e:                                   # pragma: no cover
    tif_ok = False
    print("TIFF skipped:", e)
plt.close(fig)
print("FigureS1 ok  tiff=%s" % tif_ok)
