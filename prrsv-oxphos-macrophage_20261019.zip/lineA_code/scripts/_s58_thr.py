# -*- coding: utf-8 -*-
"""D3b: 阈值敏感性分析（per-ORF 比值判据失效后的替代防线）
背景: per-ORF 检验发现本数据集病毒 reads 几乎全部落在 ORF7(占比中位 0.84-1.00 且各层无梯度),
      故"亚基因组/基因组比值"不能作为阈值判据 -> 改用阈值扫描证明结论不依赖阈值选择。
做法: 对 v >= {2,5,10,20,50,100} 分别重算比较 A（样本内 viral+ vs viral-），
      宿主分母 + 宿主 pct_mito 门控, 逐样本 rank-biserial r, 跨样本单样本 t。
输出: _step33_thr.txt, _thr_sens.csv
"""
import gzip, os, io, csv
import numpy as np
from scipy import stats

QC = r"F:\Work Buudy\线A_分析\GSE247257\qc"
D = r"F:\Work Buudy\线A_分析"

MODS = [("OXNUC", "核编码OXPHOS"), ("MT", "MT编码13亚基"), ("MITOR", "线粒体核糖体"),
        ("ISG", "抗病毒ISG"), ("BIOG", "mtDNA维持机器"), ("CII", "复合体II(3/4)"),
        ("TCA", "TCA循环"), ("FAO", "脂肪酸氧化FAO")]

INF = {
    "GSM7886188": ("JA142", "3d"), "GSM7886189": ("JA142", "3d"), "GSM7886190": ("JA142", "3d"),
    "GSM7886199": ("JA142", "7d"), "GSM7886200": ("JA142", "7d"), "GSM7886201": ("JA142", "7d"),
    "GSM7886175": ("JA142", "14d"), "GSM7886176": ("JA142", "14d"), "GSM7886177": ("JA142", "14d"),
    "GSM7886184": ("JA142", "21d"), "GSM7886185": ("JA142", "21d"), "GSM7886186": ("JA142", "21d"),
    "GSM7886192": ("M8", "3d"), "GSM7886193": ("M8", "3d"), "GSM7886194": ("M8", "3d"),
    "GSM7886202": ("M8", "7d"), "GSM7886203": ("M8", "7d"), "GSM7886204": ("M8", "7d"),
    "GSM7886196": ("PJ10", "3d"), "GSM7886197": ("PJ10", "3d"), "GSM7886198": ("PJ10", "3d"),
    "GSM7886205": ("PJ10", "7d"), "GSM7886206": ("PJ10", "7d"), "GSM7886207": ("PJ10", "7d"),
}
THR = [2, 5, 10, 20, 50, 100]


def load(gsm):
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ix = {h: i for i, h in enumerate(hdr)}
        rows = [ln.rstrip("\n").split("\t") for ln in f]
    d = {"nUMI": np.array([float(r[ix["nUMI"]]) for r in rows]),
         "vir": np.array([float(r[ix["virAll"]]) for r in rows]),
         "Mpos": np.array([int(r[ix["Mpos"]]) for r in rows])}
    for k, _ in MODS:
        d[k] = np.array([float(r[ix["sum_" + k]]) for r in rows])
    d["host"] = np.maximum(d["nUMI"] - d["vir"], 1.0)
    d["gate"] = (d["Mpos"] >= 1) & (d["MT"] / d["host"] * 100.0 <= 15)
    d["S"] = {k: np.log1p(d[k] / d["host"] * 1e4) for k, _ in MODS}
    return d


def main():
    cache = {g: load(g) for g in INF}
    L = []
    W = L.append
    W("=" * 104)
    W("【D3b 阈值敏感性】viral+ 判定阈值扫描（宿主分母 + 宿主 pct_mito 门控）")
    W("=" * 104)
    W("读法: 各阈值下 12 个样本的均值 r 与显著样本数; 结论应在多个阈值下保持同号同量级。")
    W("")

    rows = []
    for k, name in MODS:
        W(f"--- {name} ---")
        W(f"{'阈值':>6}{'纳入样本':>9}{'viral+细胞合计':>15}{'均值 r':>11}{'同向数':>9}"
          f"{'t 检验 p':>12}{'判读':>14}")
        for th in THR:
            rs, ncell = [], 0
            for g, (st, dp) in INF.items():
                a = cache[g]
                gt = a["gate"]
                pos = gt & (a["vir"] >= th)
                neg = gt & (a["vir"] == 0)
                if pos.sum() < 10 or neg.sum() < 10:
                    continue
                s = a["S"][k]
                u, p = stats.mannwhitneyu(s[pos], s[neg], alternative="two-sided")
                rs.append(2.0 * u / (pos.sum() * neg.sum()) - 1.0)
                ncell += int(pos.sum())
            if len(rs) < 3:
                W(f"{th:>6}{len(rs):>9}{ncell:>15}{'—':>11}{'—':>9}{'—':>12}{'样本不足':>14}")
                continue
            rs = np.array(rs)
            t, p = stats.ttest_1samp(rs, 0.0)
            conc = sum(1 for x in rs if np.sign(x) == np.sign(rs.mean()))
            verd = "显著升" if (p < 0.05 and rs.mean() > 0) else \
                   ("显著降" if (p < 0.05 and rs.mean() < 0) else "不显著")
            W(f"{th:>6}{len(rs):>9}{ncell:>15}{rs.mean():>+11.4f}{conc:>6}/{len(rs):<3}"
              f"{p:>12.5f}{verd:>14}")
            rows.append([k, th, len(rs), ncell, f"{rs.mean():.6f}", f"{p:.6e}", f"{conc}/{len(rs)}"])
        W("")

    with io.open(os.path.join(D, "_thr_sens.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["module", "threshold_v", "n_samples", "n_pos_cells", "mean_r", "p", "concordant"])
        for r in rows:
            w.writerow(r)

    W("解 读: 若 OXNUC 在 v>=50 与 v>=100 仍显著为负、MT 仍显著为正 -> 结论不依赖阈值选择,")
    W("       环境 RNA 污染不可能解释主结论; 若仅低阈值显著 -> 须承认结论对阈值敏感。")

    with io.open(os.path.join(D, "_step33_thr.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("done")


if __name__ == "__main__":
    main()
