# -*- coding: utf-8 -*-
"""评审意见重分析：基因清单核对 + Comparison B 动物级 + GSE304527 样本级模块分数"""
import gzip, os, re, io, csv
import numpy as np
from scipy import stats

D = r"F:/Work Buudy/线A_分析"
OUT = io.StringIO()
def log(*a): print(*a, file=OUT)

# ============================================================
# Part 1: 基因清单重生成（_s46_qc.py 最终代码 + features 矩阵）
# ============================================================
log("=" * 100)
log("【Part 1】模块基因清单重生成（_s46_qc.py 定义 vs GSE247257 features 30,504 条目）")
log("=" * 100)
FSRC = os.path.join(D, "GSE247257", "raw_full", "GSM7886175_BALC-14d-19-features.tsv.gz")
with gzip.open(FSRC, "rt", encoding="utf-8", errors="replace") as f:
    syms = [l.split("\t")[1].strip() for l in f if l.strip()]
log("features 总数 = %d" % len(syms))

MT13 = ["ND1","ND2","COX1","COX2","ATP8","ATP6","COX3","ND3","ND4L","ND4","ND5","ND6","CYTB"]
def bysym(names):
    S = set(names)
    return [i for i, s in enumerate(syms) if s in S]
MODDEF = {
    "MT":  bysym(MT13),
    "OXNUC": [i for i,s in enumerate(syms) if re.match(r"^NDUF",s) or re.match(r"^SDH[ABCD]$",s)
              or s.startswith("UQCR") or s=="CYC1" or re.match(r"^COX(4|5|6|7|8)",s) or s.startswith("ATP5")],
    "CII":  bysym(["SDHA","SDHB","SDHC","SDHD"]),
    "TCA":  bysym(["CS","ACO1","ACO2","IDH1","IDH2","IDH3A","IDH3B","IDH3G","OGDH","OGDHL",
                   "SUCLA2","SUCLG1","SUCLG2","FH","MDH1","MDH2","DLD","DLST","PC","PCK2","MPC1","MPC2"]),
    "FAO":  bysym(["CPT1A","CPT1B","CPT2","SLC25A20","ACADVL","ACADM","ACADS","ACADL","ACADSB",
                   "ACAA1","ACAA2","HADHA","HADHB","HADH","ECHS1","ECI1","ACAT1","ETFA","ETFB","ETFDH","ACOX1"]),
    "MITOR":[i for i,s in enumerate(syms) if s.startswith("MRPL") or s.startswith("MRPS")],
    "BIOG": bysym(["POLRMT","TFAM","TFB2M","SSBP1","POLG","POLG2","TWNK","MTERF1","MTERF2","MTERF3","MTERF4"]),
    "ISG":  bysym(["ISG15","MX1","MX2","OAS1","OAS2","OASL","IFIT1","IFIT2","IFIT3","IFITM1","IFITM3",
                   "RSAD2","BST2","DDX58","IFIH1","MB21D1","TMEM173","TBK1","IRF3","IRF7","STAT1","STAT2"]),
}
PANEL = {"MT":13,"OXNUC":"regex","CII":4,"TCA":22,"FAO":21,"MITOR":"regex","BIOG":11,"ISG":22}
for k in MODDEF:
    present = sorted(set(syms[i] for i in MODDEF[k]))
    panel = PANEL[k]
    log("  %-6s panel=%-5s present=%d  -> %s" % (k, panel, len(present), ",".join(present)))
log("")

# ============================================================
# Part 2: Comparison B 动物级重分析
# ============================================================
log("=" * 100)
log("【Part 2】Comparison B 动物级重分析（宿主分母得分，动物=独立单位，阻断 time-point）")
log("=" * 100)
QC = os.path.join(D, "GSE247257", "qc")
MODS = [("OXNUC","Nuclear OXPHOS"),("MT","MT-13"),("CII","Complex II"),
        ("TCA","TCA"),("FAO","FAO"),("MITOR","Mitoribo"),("BIOG","mtDNA maint"),("ISG","ISG")]

# 12 evaluable 感染动物（动物号来自 _s51_main.py INF；同时点 3 只/组）
INF = {
 "GSM7886199": ("JA142","7d","16"), "GSM7886200": ("JA142","7d","17"), "GSM7886201": ("JA142","7d","18"),
 "GSM7886175": ("JA142","14d","19"), "GSM7886176": ("JA142","14d","20"), "GSM7886177": ("JA142","14d","21"),
 "GSM7886196": ("PJ10","3d","31"), "GSM7886197": ("PJ10","3d","32"), "GSM7886198": ("PJ10","3d","33"),
 "GSM7886205": ("PJ10","7d","34"), "GSM7886206": ("PJ10","7d","35"), "GSM7886207": ("PJ10","7d","36"),
}
CTRL = {
 "3d": ["GSM7886187","GSM7886191","GSM7886195"],
 "7d": ["GSM7886208","GSM7886209","GSM7886210"],
 "14d":["GSM7886178","GSM7886179","GSM7886180"],
}
def load(gsm):
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t"); ix = {h:i for i,h in enumerate(hdr)}
        rows = [ln.rstrip("\n").split("\t") for ln in f]
    d = {"nUMI": np.array([float(r[ix["nUMI"]]) for r in rows]),
         "vir": np.array([float(r[ix["virAll"]]) for r in rows]),
         "Mpos": np.array([int(r[ix["Mpos"]]) for r in rows])}
    for k,_ in MODS: d[k] = np.array([float(r[ix["sum_"+k]]) for r in rows])
    host = np.maximum(d["nUMI"]-d["vir"],1.0)
    gate = (d["Mpos"]>=1) & (d["MT"]/host*100.0 <= 15)
    S = {k: np.log1p(d[k]/host*1e4) for k,_ in MODS}
    return d, host, gate, S

# 动物级中位得分
animal = {}   # gsm -> (group, strain, dpi, animal_id, {module: median score})
for g,(st,dp,aid) in INF.items():
    d,host,gate,S = load(g)
    neg = gate & (d["vir"]==0)
    animal[g] = ("bystander", st, dp, aid, {k: float(np.median(S[k][neg])) for k,_ in MODS})
for dp,gs in CTRL.items():
    for g in gs:
        d,host,gate,S = load(g)
        animal[g] = ("control","Neg",dp,g, {k: float(np.median(S[k][gate])) for k,_ in MODS})

# 输出动物-文库映射 + 每动物每模块得分（供补充表）
log("\n--- 动物-文库映射（Comparison B 动物级重分析用）---")
log("%-14s %-10s %-6s %-4s %-8s" % ("Library","Group","Strain","dpi","Animal"))
for g,(grp,st,dp,aid,_) in sorted(animal.items(), key=lambda x:(x[1][2], x[1][1], x[1][0])):
    log("%-14s %-10s %-6s %-4s %-8s" % (g, grp, st, dp, aid))

# 阻断模型：score ~ group(bystander vs control) + dpi(3/7/14)
# 设计矩阵：intercept, group(1=bypass,0=control), dpi7, dpi14
log("\n--- 阻断线性模型（动物级，n=%d）：score ~ group + dpi；β_group 即 challenged-animal 效应（log1p 单位）---" % len(animal))
def block_model(mod):
    rows = []
    for g,(grp,st,dp,aid,sc) in animal.items():
        y = sc[mod]
        x = [1.0, 1.0 if grp=="bystander" else 0.0,
             1.0 if dp=="7d" else 0.0, 1.0 if dp=="14d" else 0.0]
        rows.append((y,x))
    X = np.array([x for _,x in rows]); y = np.array([y for y,_ in rows])
    n,p = X.shape
    beta,res,rank,sv = np.linalg.lstsq(X,y,rcond=None)
    resid = y - X@beta
    dof = n-p
    s2 = resid@resid/dof
    cov = s2*np.linalg.inv(X.T@X)
    se = np.sqrt(np.diag(cov))
    t = beta/se
    pval = 2*(1-stats.t.cdf(np.abs(t),dof))
    ci = beta[1] + np.array([-1.0,1.0])*stats.t.ppf(0.975,dof)*se[1]
    return beta[1], se[1], pval[1], ci[0], ci[1], dof, beta, resid

summ = []
for k,name in MODS:
    b,se,p,lo,hi,dof,beta,resid = block_model(k)
    # 标准效应量 Cohen's d
    sd_pool = np.std(np.concatenate([[animal[g][4][k] for g in animal]]))
    d = b/sd_pool
    summ.append((k,name,b,lo,hi,p,dof,d))
    log("  %-14s beta=%+.4f  95%%CI [%+.4f, %+.4f]  p=%.4g  Cohen's d=%+.3f  (df=%d)" %
        (name,b,lo,hi,p,d,dof))

# BH 8 模块
ps = np.array([s[5] for s in summ])
o = np.argsort(ps); m=len(ps); q=np.empty(m); prev=1.0
for r in range(m-1,-1,-1):
    i=o[r]; prev=min(prev, ps[i]*m/(r+1)); q[i]=prev
log("\n--- BH-FDR（8 模块内校正，动物级阻断模型 P 值）---")
for (k,name,b,lo,hi,p,dof,d),qq in zip(summ,q):
    log("  %-14s beta=%+.4f  p=%.4g  q=%.4g  %s" % (name,b,p,qq,"q<0.05" if qq<0.05 else ""))

# 每动物 Δ（旁分泌 − 同龄对照池中位），描述性
log("\n--- 每动物 Δ（bystander − 同龄对照池中位，log1p）---")
ctrl_med = {dp: {k: float(np.median([animal[g][4][k] for g in gs]))
                 for k,_ in MODS} for dp,gs in CTRL.items()}
for k,name in MODS:
    deltas = []
    for g,(grp,st,dp,aid,sc) in animal.items():
        if grp=="bystander":
            deltas.append(sc[k]-ctrl_med[dp][k])
    arr = np.array(deltas)
    t,p = stats.ttest_1samp(arr,0.0)
    lo = arr.mean()-stats.t.ppf(0.975,len(arr)-1)*arr.std(ddof=1)/np.sqrt(len(arr))
    hi = arr.mean()+stats.t.ppf(0.975,len(arr)-1)*arr.std(ddof=1)/np.sqrt(len(arr))
    log("  %-14s n=%d  meanΔ=%+.4f  [%+.4f,%+.4f]  p=%.4g  (注：共享对照，非独立，仅供描述)" %
        (name,len(arr),arr.mean(),lo,hi,p))

log("")
print(OUT.getvalue())
with open(os.path.join(D,"_reanalysis_review.txt"),"w",encoding="utf-8") as f:
    f.write(OUT.getvalue())
print("WROTE _reanalysis_review.txt")
