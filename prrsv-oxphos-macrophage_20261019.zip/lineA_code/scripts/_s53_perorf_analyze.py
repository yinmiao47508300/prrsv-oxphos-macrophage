# -*- coding: utf-8 -*-
"""D3: per-ORF 机制性阈值验证
判据: 真感染以亚基因组 RNA 为主(ORF7/N 最丰), 环境病毒颗粒以基因组 RNA 为主(ORF1a/1b 最丰)
      -> 计算每细胞 ORF7 占比 = ORF7 / (该细胞自身毒株全部病毒 reads)
      -> 若随 viral UMI 升高而升高, 则证明高 viral UMI = 真感染, 低 viral UMI = 环境 RNA
辅助: (a) 样内主导毒株自证(同时测跨毒株污染); (b) viral UMI 与 nUMI 的相关性(环境 RNA 特征)
输出: _step30_perorf.txt + _perorf_cells.tsv.gz
"""
import gzip, os, io
import numpy as np
from scipy import stats

PER = r"F:\Work Buudy\线A_分析\GSE247257\perorf"
QC = r"F:\Work Buudy\线A_分析\GSE247257\qc"
OUT = r"F:\Work Buudy\线A_分析\_step30_perorf.txt"
CELLS = r"F:\Work Buudy\线A_分析\_perorf_cells.tsv.gz"

STRAINS = ["JA142", "NA8", "NA10"]
ORFS = ["ORF1a", "ORF1b", "ORF2a", "ORF2b", "ORF3", "ORF4", "ORF5", "ORF6", "ORF7"]
STRATA = [(1, 1), (2, 4), (5, 9), (10, 19), (20, 49), (50, 99), (100, 199), (200, 10 ** 9)]
SLABEL = ["1", "2-4", "5-9", "10-19", "20-49", "50-99", "100-199", ">=200"]


def gsms():
    return sorted(f[: -len("_perorf.tsv.gz")] for f in os.listdir(PER) if f.endswith("_perorf.tsv.gz"))


def read_perorf(gsm):
    p = os.path.join(PER, gsm + "_perorf.tsv.gz")
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ix = {h: i for i, h in enumerate(hdr)}
        bc, arr = [], []
        for ln in f:
            r = ln.rstrip("\n").split("\t")
            v = r[ix["virAll"]]
            if v in ("0", "0.0", "0.0000"):
                continue
            bc.append(r[ix["barcode"]])
            arr.append([float(r[ix[s + "_" + o]]) for s in STRAINS for o in ORFS])
    if not bc:
        return None, None
    return bc, np.array(arr, dtype=np.float64).reshape(len(bc), 3, 9)


def read_gate(gsm):
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    d = {}
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ix = {h: i for i, h in enumerate(hdr)}
        for ln in f:
            r = ln.rstrip("\n").split("\t")
            d[r[ix["barcode"]]] = (int(r[ix["nUMI"]]), float(r[ix["pct_mito"]]), int(r[ix["Mpos"]]),
                                   int(r[ix["virAll"]]))
    return d


def main():
    L = []
    W = L.append
    W("=" * 108)
    W("【D3 per-ORF 机制性阈值验证】ORF7 占比 = ORF7 / 该细胞自身毒株全部病毒 reads")
    W("=" * 108)
    W("预期: 真感染 -> 亚基因组 RNA 主导 -> ORF7 占比高; 环境病毒颗粒 -> 基因组 RNA 主导 -> ORF7 占比低")
    W("")

    W("--- (a) 样内主导毒株自证 与 跨毒株污染率 ---")
    W(f"{'GSM':<13}{'主导毒株':>10}{'主导 reads':>12}{'另两株 reads':>14}{'污染率':>10}{'有病毒reads细胞':>16}")
    dom = {}
    for g in gsms():
        bc, A = read_perorf(g)
        if bc is None:
            dom[g] = None
            W(f"{g:<13}{'(无)':>10}{0:>12d}{0:>14d}{'-':>10}{0:>16d}")
            continue
        tot = A.sum(axis=(0, 2))
        k = int(np.argmax(tot))
        other = float(tot.sum() - tot[k])
        dom[g] = STRAINS[k]
        W(f"{g:<13}{STRAINS[k]:>10}{tot[k]:>12.0f}{other:>14.0f}"
          f"{(other / tot.sum() * 100 if tot.sum() else 0):>9.2f}%{len(bc):>16d}")

    # ---- 汇总 per-cell ----
    W("")
    W("--- (b) 按 viral UMI 分层: ORF7 占比 与 亚基因组/基因组比值 ---")
    W(f"{'viral UMI 层':<14}{'n细胞':>10}{'ORF7 占比中位':>16}{'ORF7 占比均值':>16}"
      f"{'sg/gen 比值中位':>18}{'ORF1a/1b 中位':>16}")
    pooled = {"v": [], "sgfrac": [], "ratio": [], "gsm": [], "strain": [], "nUMI": [], "pct_mito": []}
    ncell = 0
    for g in gsms():
        if dom.get(g) is None:
            continue
        st = STRAINS.index(dom[g])
        bc, A = read_perorf(g)
        gate = read_gate(g)
        keep = [i for i, b in enumerate(bc) if b in gate and gate[b][2] >= 1 and gate[b][1] <= 15]
        if not keep:
            continue
        ncell += len(keep)
        own = A[keep, st, :]
        v = own.sum(axis=1)
        sg = own[:, 8]                      # ORF7 (N)
        ge = own[:, 0] + own[:, 1]          # ORF1a + ORF1b
        sgfrac = np.divide(sg, v, out=np.zeros_like(sg), where=v > 0)
        ratio = np.divide(sg, np.maximum(ge, 1e-9))
        nu = np.array([gate[bc[i]][0] for i in keep], dtype=float)
        pm = np.array([gate[bc[i]][1] for i in keep], dtype=float)
        pooled["v"].extend(v.tolist())
        pooled["sgfrac"].extend(sgfrac.tolist())
        pooled["ratio"].extend(ratio.tolist())
        pooled["gsm"].extend([g] * len(keep))
        pooled["strain"].extend([dom[g]] * len(keep))
        pooled["nUMI"].extend(nu.tolist())
        pooled["pct_mito"].extend(pm.tolist())

    if ncell == 0:
        W("尚无可用 per-ORF 数据")
    else:
        v = np.array(pooled["v"]); sf = np.array(pooled["sgfrac"]); rt = np.array(pooled["ratio"])
        for (lo, hi), lab in zip(STRATA, SLABEL):
            m = (v >= lo) & (v <= hi)
            if m.sum() == 0:
                continue
            W(f"{lab:<14}{int(m.sum()):>10d}{np.median(sf[m]):>16.4f}{sf[m].mean():>16.4f}"
              f"{np.median(rt[m]):>18.4f}{'-':>16}")

        W("")
        W("--- (c) 相关性检验 ---")
        rho, p = stats.spearmanr(v, sf)
        W(f"  Spearman( viral UMI, ORF7 占比 ) = {rho:+.4f}   p = {p:.3e}   "
          f"{'-> 支持: 病毒载量越高越像真感染' if rho > 0 else '-> 与预期相反'}")
        rho2, p2 = stats.spearmanr(v, np.array(pooled["nUMI"]))
        W(f"  Spearman( viral UMI, 细胞 nUMI ) = {rho2:+.4f}   p = {p2:.3e}   "
          f"{'-> 正相关提示含环境 RNA 成分' if rho2 > 0.1 else '-> 无明显深度依赖, 不支持环境 RNA 主导'}")
        rho3, p3 = stats.spearmanr(np.array(pooled["nUMI"]), sf)
        W(f"  Spearman( 细胞 nUMI, ORF7 占比 ) = {rho3:+.4f}   p = {p3:.3e}   "
          f"{'-> 高深度细胞更偏亚基因组, 支持真感染' if rho3 > 0 else '-> 无正向关联'}")

        # 阈值附近的关键对比
        W("")
        W("--- (d) 阈值邻近区间的 ORF7 占比(决定 v>=10 是否落在切换点) ---")
        for lo, hi, tag in [(1, 1, "v=1"), (2, 4, "v=2-4"), (5, 9, "v=5-9"),
                            (10, 19, "v=10-19"), (20, 49, "v=20-49")]:
            m = (v >= lo) & (v <= hi)
            if m.sum() == 0:
                continue
            W(f"  {tag:<9} n={int(m.sum()):<7d} ORF7 占比中位={np.median(sf[m]):.4f}  "
              f"均值={sf[m].mean():.4f}  sg/gen 中位={np.median(rt[m]):.4f}")

        # 导出 per-cell
        with gzip.open(CELLS, "wt") as f:
            f.write("gsm\tstrain\tv\tsgfrac\tsg_gen_ratio\tnUMI\tpct_mito\n")
            for i in range(ncell):
                f.write(f"{pooled['gsm'][i]}\t{pooled['strain'][i]}\t{v[i]:.0f}\t{sf[i]:.5f}\t"
                        f"{rt[i]:.5f}\t{pooled['nUMI'][i]:.0f}\t{pooled['pct_mito'][i]:.3f}\n")

    W("")
    W("判读: ORF7 占比随 viral UMI 升高而升高 -> 高 viral UMI 细胞是真感染, 阈值有机制依据;")
    W("      若各层 ORF7 占比持平且偏低 -> viral UMI 主要来自环境病毒颗粒, 阈值须上调或改用比值判定。")

    with io.open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("done")


if __name__ == "__main__":
    main()
