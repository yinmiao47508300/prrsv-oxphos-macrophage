# -*- coding: utf-8 -*-
"""GSE247257 QC + 巨噬细胞标志 + 病毒 ORF + 模块得分（单遍流式，不物化矩阵）
   输出：每样本一张紧凑 per-cell TSV -> qc/<GSM>_percell.tsv.gz
"""
import gzip, os, re, sys, time
import numpy as np

RAW = r"F:\Work Buudy\线A_分析\GSE247257\raw_full"
OUTD = r"F:\Work Buudy\线A_分析\GSE247257\qc"
LOG = r"F:\Work Buudy\线A_分析\_qc_progress.log"
os.makedirs(OUTD, exist_ok=True)

def log(s):
    with open(LOG, "a", encoding="utf-8") as f:
        f.write("%s  %s\n" % (time.strftime("%H:%M:%S"), s))

# ---------- 读一次 features（36 样本共用） ----------
fsrc = os.path.join(RAW, "GSM7886175_BALC-14d-19-features.tsv.gz")
with gzip.open(fsrc, "rt", encoding="utf-8", errors="replace") as f:
    syms = [l.split("\t")[1].strip() for l in f if l.strip()]
NG = len(syms)
assert NG == 30504, NG

MT13 = ["ND1","ND2","COX1","COX2","ATP8","ATP6","COX3","ND3","ND4L","ND4","ND5","ND6","CYTB"]
VIR = [(i, s) for i, s in enumerate(syms) if re.match(r"^(JA142|NA8|NA10)_ORF", s)]
VIR_IDX = [i for i, _ in VIR]
VIR_STRAIN = {}
for st in ("JA142", "NA8", "NA10"):
    VIR_STRAIN[st] = [i for i, s in enumerate(syms) if s.startswith(st + "_ORF")]

def bysym(names):
    S = set(names)
    return [i for i, s in enumerate(syms) if s in S]

MODSETS = {
    "MT":      bysym(MT13),
    "OXNUC":   [i for i, s in enumerate(syms) if re.match(r"^NDUF", s) or re.match(r"^SDH[ABCD]$", s)
                or s.startswith("UQCR") or s == "CYC1" or re.match(r"^COX(4|5|6|7|8)", s) or s.startswith("ATP5")],
    "CII":     bysym(["SDHA","SDHB","SDHC","SDHD"]),
    "TCA":     bysym(["CS","ACO1","ACO2","IDH1","IDH2","IDH3A","IDH3B","IDH3G","OGDH","OGDHL",
                      "SUCLA2","SUCLG1","SUCLG2","FH","MDH1","MDH2","DLD","DLST","PC","PCK2","MPC1","MPC2"]),
    "FAO":     bysym(["CPT1A","CPT1B","CPT2","SLC25A20","ACADVL","ACADM","ACADS","ACADL","ACADSB",
                      "ACAA1","ACAA2","HADHA","HADHB","HADH","ECHS1","ECI1","ACAT1","ETFA","ETFB","ETFDH","ACOX1"]),
    "MITOR":   [i for i, s in enumerate(syms) if s.startswith("MRPL") or s.startswith("MRPS")],
    "BIOG":    bysym(["POLRMT","TFAM","TFB2M","SSBP1","POLG","POLG2","TWNK","MTERF1","MTERF2","MTERF3","MTERF4"]),
    "ISG":     bysym(["ISG15","MX1","MX2","OAS1","OAS2","OASL","IFIT1","IFIT2","IFIT3","IFITM1","IFITM3",
                      "RSAD2","BST2","DDX58","IFIH1","MB21D1","TMEM173","TBK1","IRF3","IRF7","STAT1","STAT2"]),
}
MARK = {}
for g in ["CD163","CSF1R","SPP1","MARCO","CD68"]:
    MARK["M_" + g] = bysym([g])
for g in ["CD3E","CD79A","NKG7","KLRD1","EPCAM","KRT18"]:
    MARK["N_" + g] = bysym([g])

GROUPS = {}
for k, v in MODSETS.items():
    GROUPS[k] = v
for k, v in MARK.items():
    GROUPS[k] = v
GROUPS["VIR_ALL"] = VIR_IDX
for st, v in VIR_STRAIN.items():
    GROUPS["VIR_" + st] = v
GROUPS["MITO"] = MODSETS["MT"]

GNAMES = list(GROUPS.keys())
GIDX = {g: i for i, g in enumerate(GNAMES)}
NGROUP = len(GNAMES)

# gene_idx -> 所属 group 列表
g2groups = {}
for gname, idxs in GROUPS.items():
    gi = GIDX[gname]
    for i in idxs:
        g2groups.setdefault(i, []).append(gi)

log("=== QC 开始 | feature=%d | group=%d | 病毒=%d | MT=%d ===" % (NG, NGROUP, len(VIR_IDX), len(MODSETS["MT"])))
log("模块基因数: " + " ".join("%s=%d" % (k, len(v)) for k, v in MODSETS.items()))
log("缺失检查: " + " ".join("%s=%d" % (k, len(v)) for k, v in MARK.items()))

# ---------- 逐样本 ----------
import glob
mats = sorted(glob.glob(os.path.join(RAW, "*matrix.mtx.gz")))
log("matrix 文件数 = %d" % len(mats))

HEADER = ["barcode","nUMI","nGene","pct_mito","virAll","virJA142","virNA8","virNA10"] + \
         ["sum_" + g for g in GNAMES] + ["Mpos","Npos"]

t_all = time.time()
summary = []
for k, mp in enumerate(mats):
    stem = os.path.basename(mp)[:-len("-matrix.mtx.gz")]
    gsm = stem.split("_")[0]
    dst = os.path.join(OUTD, gsm + "_percell.tsv.gz")
    if os.path.exists(dst):
        log("[%2d/%d] %s  已存在，跳过" % (k + 1, len(mats), gsm))
        continue
    t0 = time.time()
    # barcodes
    bpath = os.path.join(RAW, stem + "-barcodes.tsv.gz")
    with gzip.open(bpath, "rt", encoding="utf-8", errors="replace") as f:
        barcodes = [l.strip() for l in f if l.strip()]
    nc = len(barcodes)

    tot = np.zeros(nc, dtype=np.float64)
    ngene = np.zeros(nc, dtype=np.int32)
    sums = np.zeros((NGROUP, nc), dtype=np.float64)

    gi_mito = GIDX["MITO"]
    with gzip.open(mp, "rt", encoding="utf-8", errors="replace") as f:
        line = f.readline()
        dims = None
        while True:
            line = f.readline()
            if not line:
                break
            if line.startswith("%"):
                continue
            dims = line.split()
            break
        assert dims is not None
        nrow, ncol, nnz = int(dims[0]), int(dims[1]), int(dims[2])
        assert nrow == NG, (nrow, NG)
        assert ncol == nc, (ncol, nc)
        for ln in f:
            p = ln.split()
            if len(p) != 3:
                continue
            gr = int(p[0]) - 1
            cc = int(p[1]) - 1
            v = float(p[2])
            tot[cc] += v
            ngene[cc] += 1
            gl = g2groups.get(gr)
            if gl:
                for gg in gl:
                    sums[gg, cc] += v

    pct_mito = np.where(tot > 0, sums[gi_mito] / np.maximum(tot, 1e-9) * 100.0, 0.0)
    Mpos = np.zeros(nc, dtype=np.int32)
    for g in ["CD163","CSF1R","SPP1","MARCO","CD68"]:
        Mpos += (sums[GIDX["M_" + g]] > 0).astype(np.int32)
    Npos = np.zeros(nc, dtype=np.int32)
    for g in ["CD3E","CD79A","NKG7","KLRD1","EPCAM","KRT18"]:
        Npos += (sums[GIDX["N_" + g]] > 0).astype(np.int32)

    keep = (ngene >= 200) & (tot > 0)
    vi = GIDX["VIR_ALL"]
    with gzip.open(dst, "wt", encoding="utf-8") as o:
        o.write("\t".join(HEADER) + "\n")
        for c in range(nc):
            if not keep[c]:
                continue
            row = [barcodes[c], "%d" % int(tot[c]), "%d" % int(ngene[c]), "%.4f" % pct_mito[c],
                   "%d" % int(sums[vi, c]),
                   "%d" % int(sums[GIDX["VIR_JA142"], c]),
                   "%d" % int(sums[GIDX["VIR_NA8"], c]),
                   "%d" % int(sums[GIDX["VIR_NA10"], c])]
            row += ["%.4f" % sums[GIDX[g], c] for g in GNAMES]
            row += ["%d" % int(Mpos[c]), "%d" % int(Npos[c])]
            o.write("\t".join(row) + "\n")

    nkeep = int(keep.sum())
    nvir = int((sums[vi][keep] >= 2).sum())
    summary.append((gsm, nc, nkeep, int((sums[vi][keep] >= 1).sum()),
                    int((sums[vi][keep] >= 2).sum()), int((sums[vi][keep] >= 3).sum())))
    log("[%2d/%d] %s  barcode=%d 通过QC=%d  viral>=1:%d  >=2:%d  >=3:%d  (%.0fs)"
        % (k + 1, len(mats), gsm, nc, nkeep, summary[-1][3], summary[-1][4], summary[-1][5], time.time() - t0))

log("=== QC 完成，总用时 %.1f 分钟 ===" % ((time.time() - t_all) / 60.0))
log("")
log("%-13s %9s %9s %9s %9s %9s" % ("GSM", "barcode", "passQC", "v>=1", "v>=2", "v>=3"))
for r in summary:
    log("%-13s %9d %9d %9d %9d %9d" % r)
print("OK")
