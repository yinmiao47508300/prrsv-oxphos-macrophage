# -*- coding: utf-8 -*-
"""Suggested new Additional file 1 panels that currently have no figure at all.

These three panels support statements already present in the manuscript but
never illustrated:

  P039 / P114  exclusive-marker gate is depth dependent
               (1.3 % vs 57.5 %; Spearman rho = -0.91, P < 1e-14, 36 libraries)
  P042         why the primary threshold is 10 viral UMIs
               (between the ambient background mode and the right tail)
  P043 / P120  ORF7 fraction by viral-UMI stratum
               (median 0.84-1.00, no gradient; blocks the subgenomic criterion)

Proposed numbering: Figure S7A, S7B, S7C.
Sources:  GSE247257/qc/*_percell.tsv.gz   and   GSE247257/perorf/*_perorf.tsv.gz

Run:  python _s58_figS7_qc_and_threshold.py
"""
import csv
import glob
import gzip
import os

import numpy as np
from scipy.stats import spearmanr
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["savefig.dpi"] = 300

MM = 1 / 25.4
HERE = os.path.dirname(os.path.abspath(__file__))
QC = os.path.join(HERE, "GSE247257", "qc")
PERORF = os.path.join(HERE, "GSE247257", "perorf")
OUT = os.path.join(HERE, "figs_en")
os.makedirs(OUT, exist_ok=True)

C_MAIN = "#1B4F72"
C_ACC = "#C0392B"
C_GREY = "#7F8C8D"
THRESHOLDS = [2, 5, 10, 20, 50, 100]
STRATA = [(1, 1), (2, 4), (5, 9), (10, 19), (20, 49), (50, 199), (200, 10 ** 9)]

meta = {r["gsm"]: r for r in csv.DictReader(
    open(os.path.join(HERE, "_final_counts.csv"), encoding="utf-8-sig"))}
EVALUABLE = sorted(g for g, m in meta.items() if int(float(m["n_pos"])) >= 10)

# ---------------------------------------------------------------------------
# pass 1 - per-library gate retention + library depth
#
# Definition deliberately identical to _chk930_gate2.py, which is the script
# that produced the numbers now quoted in the manuscript:  no nGene / nUMI
# quality filter is applied here (the gate comparison is about the effect of a
# marker rule on the raw cell set), the mitochondrial filter uses the host
# denominator, and depth is the median nUMI over *all* barcodes of a library.
# Revisit this definition explicitly if the wording in the Methods changes.
# ---------------------------------------------------------------------------
retention, depth_med = {}, {}
cell_vir = []           # viral UMI per gated macrophage, 12 evaluable libraries
for g in sorted(meta):
    p = os.path.join(QC, g + "_percell.tsv.gz")
    if not os.path.exists(p):
        continue
    base = alt = 0
    numi = []
    keep = g in EVALUABLE
    with gzip.open(p, "rt", encoding="utf-8", errors="replace") as f:
        rd = csv.DictReader(f, delimiter="\t")
        for r in rd:
            n = float(r["nUMI"])
            v = float(r["virAll"])
            h = max(n - v, 1.0)
            numi.append(n)
            if float(r["sum_MT"]) / h * 100.0 > 15.0:
                continue
            if int(float(r["Mpos"])) < 1:
                continue
            base += 1
            if int(float(r["Npos"])) == 0:
                alt += 1
            if keep:
                cell_vir.append(v)
    if base:
        retention[g] = 100.0 * alt / base
        depth_med[g] = float(np.median(numi))

gs = sorted(retention, key=lambda x: depth_med[x])
dx = np.array([depth_med[g] for g in gs])
dy = np.array([retention[g] for g in gs])
rho, rho_p = spearmanr(dx, dy)
print("gate retention: %d libraries   range %.2f%% - %.2f%%   rho = %.3f  P = %.2e"
      % (len(gs), dy.min(), dy.max(), rho, rho_p))
print("  deepest  : %s  median nUMI %.0f  retention %.1f%%"
      % (gs[-1], depth_med[gs[-1]], retention[gs[-1]]))
print("  shallowest in the low-depth batch: %s  median nUMI %.0f  retention %.1f%%"
      % (gs[0], depth_med[gs[0]], retention[gs[0]]))

# ---------------------------------------------------------------------------
# pass 2 - ORF7 fraction by viral-UMI stratum (12 evaluable libraries)
# ---------------------------------------------------------------------------
orf7 = {s: [] for s in STRATA}
for g in EVALUABLE:
    p = os.path.join(PERORF, g + "_perorf.tsv.gz")
    if not os.path.exists(p):
        continue
    with gzip.open(p, "rt", encoding="utf-8", errors="replace") as f:
        rd = csv.DictReader(f, delimiter="\t")
        orf7_cols = [c for c in rd.fieldnames if c.endswith("_ORF7")]
        for r in rd:
            v = float(r["virAll"])
            if v < 1:
                continue
            o7 = sum(float(r[c]) for c in orf7_cols)
            for lo, hi in STRATA:
                if lo <= v <= hi:
                    orf7[(lo, hi)].append(o7 / v)
                    break

print("\nORF7 fraction by viral-UMI stratum (12 evaluable libraries)")
print("%-10s %8s %8s %8s" % ("stratum", "n cells", "median", "IQR"))
med = {}
for s in STRATA:
    a = np.array(orf7[s])
    if a.size == 0:
        continue
    med[s] = float(np.median(a))
    q1, q3 = np.percentile(a, [25, 75])
    print("%-10s %8d %8.3f   %.2f-%.2f"
          % ("%d" % s[0] if s[0] == s[1] else
             ("%d-%d" % (s[0], s[1]) if s[1] < 10 ** 9 else ">=%d" % s[0]),
             a.size, med[s], q1, q3))

# ---------------------------------------------------------------------------
# figure
# ---------------------------------------------------------------------------
fig = plt.figure(figsize=(180 * MM, 210 * MM))
axA = fig.add_axes([0.075, 0.700, 0.42, 0.245])
axB = fig.add_axes([0.575, 0.700, 0.40, 0.245])
axC = fig.add_axes([0.075, 0.085, 0.90, 0.475])

# ---- A -------------------------------------------------------------------
axA.scatter(dx, dy, s=26, facecolor=C_MAIN, edgecolor="white", lw=0.5, zorder=4)
z = np.polyfit(dx, dy, 1)
xx = np.linspace(dx.min(), dx.max(), 50)
axA.plot(xx, np.polyval(z, xx), "-", color=C_ACC, lw=1.1, zorder=3)
axA.set_xlabel("Median nUMI per cell (whole library)", fontsize=7.6)
axA.set_ylabel("Cells retained by the\nexclusion-marker gate (%)", fontsize=7.6)
axA.set_ylim(-3, 72)
axA.tick_params(labelsize=7.0, width=0.7, length=2.4)
for sp in ("top", "right"):
    axA.spines[sp].set_visible(False)
axA.text(0.96, 0.94, "Spearman $\\rho$ = %.2f\n$P$ < 10$^{-14}$  ($n$ = 36)"
         % rho, transform=axA.transAxes, ha="right", va="top", fontsize=7.2)
axA.text(0.03, 0.06, "36 libraries", transform=axA.transAxes, fontsize=6.8,
         color=C_GREY)
axA.set_title("A   Exclusion-marker gate is depth dependent", fontsize=8.4,
              loc="left", fontweight="bold", pad=4)

# ---- B -------------------------------------------------------------------
cv = np.array(cell_vir)
cv = cv[cv >= 1]
bins = np.logspace(0, np.log10(max(cv.max(), 110)), 46)
axB.hist(cv, bins=bins, color="#5D6D7E", edgecolor="white", lw=0.35)
axB.set_xscale("log")
axB.set_yscale("log")
for t in THRESHOLDS:
    axB.axvline(t, color=C_ACC, lw=0.7, ls="--", alpha=0.75, zorder=5)
axB.text(10, axB.get_ylim()[1] * 0.30, "primary\nthreshold",
         fontsize=6.6, color=C_ACC, va="top", ha="left")
axB.set_xlabel("Viral UMI per gated macrophage (log scale)", fontsize=7.6)
axB.set_ylabel("Cells (log scale)", fontsize=7.6)
axB.tick_params(labelsize=7.0, width=0.7, length=2.4)
for sp in ("top", "right"):
    axB.spines[sp].set_visible(False)
axB.text(0.03, 1.0, "thresholds 2 / 5 / 10 / 20 / 50 / 100",
         transform=axB.transAxes, fontsize=6.8, color=C_ACC, va="bottom")
axB.set_title("B   Threshold between background mode and tail",
              fontsize=8.4, loc="left", fontweight="bold", pad=12)

# ---- C -------------------------------------------------------------------
labels, data, ns = [], [], []
for s in STRATA:
    a = np.array(orf7[s])
    if a.size == 0:
        continue
    labels.append("%d" % s[0] if s[0] == s[1] else
                  ("%d\u2013%d" % (s[0], s[1]) if s[1] < 10 ** 9 else
                   "$\\geq$%d" % s[0]))
    data.append(a)
    ns.append(a.size)
pos = np.arange(len(data))
bp = axC.boxplot(data, positions=pos, widths=0.55, showfliers=False,
                 patch_artist=True,
                 medianprops=dict(color="black", lw=1.3),
                 whiskerprops=dict(color="#4D5656", lw=0.8),
                 capprops=dict(color="#4D5656", lw=0.8))
for patch in bp["boxes"]:
    patch.set_facecolor("#D6EAF8")
    patch.set_edgecolor("#34495E")
    patch.set_linewidth(0.7)
axC.set_xticks(pos)
axC.set_xticklabels(["%s\n(n = %d)" % (l, n) for l, n in zip(labels, ns)],
                    fontsize=7.2)
axC.set_xlabel("Viral UMI per cell (stratum)", fontsize=7.8)
axC.set_ylabel("ORF7 fraction of viral UMIs", fontsize=7.8)
axC.set_ylim(-0.05, 1.12)
axC.tick_params(axis="y", labelsize=7.0, width=0.7, length=2.4)
for sp in ("top", "right"):
    axC.spines[sp].set_visible(False)
axC.axhline(1.0, color=C_GREY, lw=0.6, ls=":")
axC.set_title("C   ORF7 fraction does not separate low- from high-count cells",
              fontsize=8.4, loc="left", fontweight="bold", pad=4)

stem = "FigureS7_gating_depth_and_threshold"
fig.savefig(os.path.join(OUT, stem + ".png"), dpi=300)
try:
    fig.savefig(os.path.join(OUT, stem + ".tiff"), dpi=300,
                pil_kwargs={"compression": "tiff_lzw"})
    print("\ntiff ok")
except Exception as e:                                     # pragma: no cover
    print("\nTIFF skipped:", e)
plt.close(fig)
print("written to", OUT)
