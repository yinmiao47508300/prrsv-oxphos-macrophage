# -*- coding: utf-8 -*-
"""线A 补充表 S1-S4 生成器。

S1 <- _final_counts.csv          （36 文库 × 10 列）
S2 <- 由 GSE247257 feature 注释重建（与 _s46_qc.py 同一套匹配逻辑）
S3 <- _final_A.csv / _final_B.csv / _final_depthmatch.csv
S4 <- _thr_sens.csv

输出：xlsx（多 sheet）+ docx（A4 横向，可直接作 Additional file 1 投稿）
"""
import csv, gzip, os, re
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

D = r"F:\Work Buudy\线A_分析"
FEAT = os.path.join(D, r"GSE247257\raw_full\GSM7886175_BALC-14d-19-features.tsv.gz")
OUTDIR = r"F:\Work Buudy\线A_补充表"
os.makedirs(OUTDIR, exist_ok=True)

MODULE_ORDER = ["OXNUC", "MT", "CII", "TCA", "FAO", "MITOR", "BIOG", "ISG"]
MODULE_FULL = {
    "OXNUC": "Nuclear-encoded OXPHOS",
    "MT":    "Mitochondrially encoded subunits",
    "CII":   "Complex II",
    "TCA":   "TCA cycle",
    "FAO":   "Fatty acid oxidation",
    "MITOR": "Mitoribosome",
    "BIOG":  "mtDNA maintenance",
    "ISG":   "Antiviral / interferon-stimulated genes",
}
QC_LOG_COUNTS = {"MT": 13, "OXNUC": 74, "CII": 3, "TCA": 21,
                 "FAO": 20, "MITOR": 66, "BIOG": 10, "ISG": 17}


def readcsv(name):
    with open(os.path.join(D, name), encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def fmt_p(p):
    """P 值排版：0 / 极小值 / 常规。"""
    try:
        v = float(p)
    except Exception:
        return str(p)
    if v == 0:
        return "< 1e-300"
    if v < 1e-4:
        s = ("%.2e" % v)
        m, e = s.split("e")
        return "%s x 10^%d" % (m, int(e))
    return "%.4f" % v


def fmt_dpi(s):
    """'14d' -> '14'；表头已注明单位 dpi，值不再重复带 d。"""
    return str(s).rstrip("dD")


def fmt_strain(s):
    """阴性对照文库无毒株，用破折号占位。"""
    return "–" if s in ("Negative", "", None) else str(s)


def fmt_r(x, nd=4):
    return ("%." + str(nd) + "f") % float(x)


# =====================================================================
# Table S2 —— 模块基因列表（从 feature 注释重建，与 _s46_qc.py 逻辑一致）
# =====================================================================
def build_s2():
    with gzip.open(FEAT, "rt", encoding="utf-8", errors="replace") as f:
        syms = [l.split("\t")[1].strip() for l in f if l.strip()]
    assert len(syms) == 30504, len(syms)

    def bysym(names):
        S = set(names)
        return [i for i, s in enumerate(syms) if s in S]

    MT13 = ["ND1", "ND2", "COX1", "COX2", "ATP8", "ATP6", "COX3",
            "ND3", "ND4L", "ND4", "ND5", "ND6", "CYTB"]
    PANEL = {
        "MT":    MT13,
        "OXNUC": [s for s in syms if re.match(r"^NDUF", s) or re.match(r"^SDH[ABCD]$", s)
                  or s.startswith("UQCR") or s == "CYC1"
                  or re.match(r"^COX(4|5|6|7|8)", s) or s.startswith("ATP5")],
        "CII":   ["SDHA", "SDHB", "SDHC", "SDHD"],
        "TCA":   ["CS", "ACO1", "ACO2", "IDH1", "IDH2", "IDH3A", "IDH3B", "IDH3G", "OGDH",
                  "OGDHL", "SUCLA2", "SUCLG1", "SUCLG2", "FH", "MDH1", "MDH2", "DLD", "DLST",
                  "PC", "PCK2", "MPC1", "MPC2"],
        "FAO":   ["CPT1A", "CPT1B", "CPT2", "SLC25A20", "ACADVL", "ACADM", "ACADS", "ACADL",
                  "ACADSB", "ACAA1", "ACAA2", "HADHA", "HADHB", "HADH", "ECHS1", "ECI1",
                  "ACAT1", "ETFA", "ETFB", "ETFDH", "ACOX1"],
        "MITOR": [s for s in syms if s.startswith("MRPL") or s.startswith("MRPS")],
        "BIOG":  ["POLRMT", "TFAM", "TFB2M", "SSBP1", "POLG", "POLG2", "TWNK",
                  "MTERF1", "MTERF2", "MTERF3", "MTERF4"],
        "ISG":   ["ISG15", "MX1", "MX2", "OAS1", "OAS2", "OASL", "IFIT1", "IFIT2", "IFIT3",
                  "IFITM1", "IFITM3", "RSAD2", "BST2", "DDX58", "IFIH1", "MB21D1", "TMEM173",
                  "TBK1", "IRF3", "IRF7", "STAT1", "STAT2"],
    }
    rows = [["Module", "Abbreviation", "Genes in panel (n)",
             "Present in GSE247257 feature annotation (n)", "Gene symbols present in the annotation"]]
    for k in MODULE_ORDER:
        panel = sorted(set(PANEL[k]))
        idx = bysym(panel)
        present = sorted(set(syms[i] for i in idx))
        ok = (len(present) == QC_LOG_COUNTS[k])
        print("S2 %-6s panel=%-3d present=%-3d QClog=%-3d %s"
              % (k, len(panel), len(present), QC_LOG_COUNTS[k], "OK" if ok else "** MISMATCH **"))
        rows.append([MODULE_FULL[k], k, len(panel), len(present), ", ".join(present)])
    return rows


# =====================================================================
# Table S1 / S3 / S4
# =====================================================================
def build_s1():
    rows = readcsv("_final_counts.csv")
    order = {"Negative": 0, "Infected": 1}
    sar = {"JA142": 0, "M8": 1, "PJ10": 2}
    rows.sort(key=lambda r: (order.get(r["group"], 9), sar.get(r["strain"], 9), r["dpi"]))
    out = [["Library (GSM)", "Group", "Strain", "Time point (dpi)",
            "Gated macrophages", "Viral-positive cells", "Viral-negative cells",
            "Host UMI per cell (median)", "Viral fraction of total UMI (median, %)",
            "Maximum viral UMI per cell"]]
    for r in rows:
        out.append([r["gsm"], r["group"], fmt_strain(r["strain"]), fmt_dpi(r["dpi"]),
                    int(r["n_gate"]), int(r["n_pos"]), int(r["n_neg"]),
                    int(r["host_numi_med"]), "%.3f" % float(r["vir_frac_med_pct"]),
                    int(r["vir_max"])])
    return out


def build_s3():
    A = readcsv("_final_A.csv")
    B = readcsv("_final_B.csv")
    Dm = readcsv("_final_depthmatch.csv")
    sar = {"JA142": 0, "M8": 1, "PJ10": 2}
    mod = {m: i for i, m in enumerate(MODULE_ORDER)}

    def key(r):
        return (sar.get(r["strain"], 9), r["dpi"], mod.get(r["module"], 9), r["gsm"])

    a = [["Library (GSM)", "Strain", "Time point (dpi)", "Module", "Module name",
          "Rank-biserial r", "P", "Viral-positive cells (n)", "Viral-negative cells (n)"]]
    for r in sorted(A, key=key):
        a.append([r["gsm"], fmt_strain(r["strain"]), fmt_dpi(r["dpi"]), r["module"], MODULE_FULL[r["module"]],
                  fmt_r(r["r"], 3), fmt_p(r["p"]), int(r["n_pos"]), int(r["n_neg"])])

    b = [["Library (GSM)", "Strain", "Time point (dpi)", "Module", "Module name",
          "Rank-biserial r", "P", "Viral-negative bystanders (n)", "Uninfected controls (n)"]]
    for r in sorted(B, key=key):
        b.append([r["gsm"], fmt_strain(r["strain"]), fmt_dpi(r["dpi"]), r["module"], MODULE_FULL[r["module"]],
                  fmt_r(r["r"], 3), fmt_p(r["p"]), int(r["n_inf_neg"]), int(r["n_ctrl"])])

    c = [["Library (GSM)", "Strain", "Time point (dpi)", "Module", "Module name",
          "Crude delta", "Depth-matched delta", "Host-nUMI decile bins (n)"]]
    for r in sorted(Dm, key=key):
        md = r["matched_delta"]
        c.append([r["gsm"], fmt_strain(r["strain"]), fmt_dpi(r["dpi"]), r["module"], MODULE_FULL[r["module"]],
                  fmt_r(r["crude_delta"], 3),
                  (fmt_r(md, 3) if md not in ("", None) else "NA"),
                  int(r["n_bins"])])
    return a, b, c


def build_s4():
    rows = readcsv("_thr_sens.csv")
    mod = {m: i for i, m in enumerate(MODULE_ORDER)}
    rows.sort(key=lambda r: (mod.get(r["module"], 9), int(r["threshold_v"])))
    out = [["Module", "Module name", "Infection threshold (viral UMI)",
            "Libraries analysed (n)", "Viral-positive cells (n)",
            "Mean rank-biserial r", "P", "Libraries with concordant direction"]]
    for r in rows:
        out.append([r["module"], MODULE_FULL[r["module"]], ">= " + r["threshold_v"],
                    int(r["n_samples"]), int(r["n_pos_cells"]),
                    fmt_r(r["mean_r"], 3), fmt_p(r["p"]), r["concordant"]])
    return out


# =====================================================================
# 写出 xlsx
# =====================================================================
HDR_FILL = PatternFill("solid", fgColor="DCE6F1")
THIN = Side(style="thin", color="9E9E9E")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def write_sheet(ws, data, widths):
    for r in data:
        ws.append(r)
    for j, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(j)].width = w
    for c in ws[1]:
        c.font = Font(bold=True, size=10)
        c.fill = HDR_FILL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=len(widths)):
        for c in row:
            c.border = BORDER
            if c.row > 1:
                c.font = Font(size=9.5)
                c.alignment = Alignment(vertical="top", wrap_text=False)


def build_xlsx(s1, s2, s3a, s3b, s3c, s4, optional5):
    wb = Workbook()
    wb.remove(wb.active)
    write_sheet(wb.create_sheet("TableS1"), s1, [15, 10, 9, 10, 13, 13, 13, 14, 15, 14])
    write_sheet(wb.create_sheet("TableS2"), s2, [30, 9, 16, 16, 120])
    write_sheet(wb.create_sheet("TableS3A_intrinsic"), s3a, [15, 9, 10, 9, 32, 11, 13, 13, 13])
    write_sheet(wb.create_sheet("TableS3B_paracrine"), s3b, [15, 9, 10, 9, 32, 11, 13, 13, 13])
    write_sheet(wb.create_sheet("TableS3C_depthmatched"), s3c, [15, 9, 10, 9, 32, 12, 14, 12])
    write_sheet(wb.create_sheet("TableS4"), s4, [9, 32, 15, 12, 14, 12, 13, 16])
    if optional5:
        write_sheet(wb.create_sheet("TableS5_optional"), optional5, [26, 12, 13, 14])
    p = os.path.join(OUTDIR, "线A_补充表S1-S4.xlsx")
    wb.save(p)
    print("xlsx ->", p)


# =====================================================================
# 写出 docx（A4 横向，可直接作 Additional file 1）
# =====================================================================
CAPTIONS = {
 "S1": "Additional file 1: Table S1. Per-library host UMI, gated macrophage counts, "
       "viral-positive and viral-negative cell counts, viral UMI maxima and viral fraction "
       "of total UMI, for all 36 libraries.",
 "S2": "Additional file 1: Table S2. Module gene lists with the number of genes present in "
       "the GSE247257 feature annotation.",
 "S3": "Additional file 1: Table S3. Per-library effect sizes for all eight modules in the "
       "intrinsic comparison (comparison A), the paracrine comparison (comparison B) and the "
       "depth-matched analysis.",
 "S4": "Additional file 1: Table S4. Complete threshold-sensitivity output for infection "
       "thresholds of >=2, >=5, >=10, >=20, >=50 and >=100 viral UMI.",
}
SUBHEAD = {
 "S3": [("A. Intrinsic comparison (comparison A): viral-positive versus viral-negative "
        "macrophages within the same library.", "a"),
        ("B. Paracrine comparison (comparison B): viral-negative bystanders within infected "
         "libraries versus age-matched uninfected controls.", "b"),
        ("C. Depth-matched analysis: crude versus within-library host-nUMI decile-matched "
         "effect sizes.", "c")],
}


def set_landscape(doc):
    for s in doc.sections:
        s.orientation = WD_ORIENT.LANDSCAPE
        s.page_width, s.page_height = Cm(29.7), Cm(21.0)
        s.left_margin = s.right_margin = Cm(1.4)
        s.top_margin = s.bottom_margin = Cm(1.4)


def repeat_header(row):
    tr = row._tr
    el = OxmlElement('w:tblHeader')
    el.set(qn('w:val'), "true")
    trPr = tr.get_or_add_trPr()
    trPr.append(el)


def add_table(doc, data, fs=7.0):
    t = doc.add_table(rows=len(data), cols=len(data[0]))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(data):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(0)
            run = p.add_run(str(val))
            run.font.size = Pt(fs)
            run.font.name = "Times New Roman"
            run._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
            run.font.bold = (i == 0)
    repeat_header(t.rows[0])
    return t


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(text)
    run.font.size = Pt(9)
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
    run.font.bold = False


def add_subhead(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(3)
    run = p.add_run(text)
    run.font.size = Pt(8.5)
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
    run.font.bold = True


def build_docx(s1, s2, s3a, s3b, s3c, s4):
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(9)
    st._element.rPr.rFonts.set(qn('w:eastAsia'), "宋体")
    set_landscape(doc)

    h = doc.add_paragraph()
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = h.add_run("Additional file 1. Supplementary tables")
    r.font.size = Pt(12)
    r.font.bold = True

    add_caption(doc, CAPTIONS["S1"]);  add_table(doc, s1)
    doc.add_page_break()
    add_caption(doc, CAPTIONS["S2"]);  add_table(doc, s2, fs=6.5)
    doc.add_page_break()
    add_caption(doc, CAPTIONS["S3"])
    for text, key in SUBHEAD["S3"]:
        add_subhead(doc, text)
        add_table(doc, {"a": s3a, "b": s3b, "c": s3c}[key], fs=6.5)
    doc.add_page_break()
    add_caption(doc, CAPTIONS["S4"]);  add_table(doc, s4, fs=7.5)

    p = os.path.join(OUTDIR, "线A_Additional_file_1_补充表S1-S4.docx")
    doc.save(p)
    print("docx ->", p)


if __name__ == "__main__":
    s2 = build_s2()
    s1 = build_s1()
    s3a, s3b, s3c = build_s3()
    s4 = build_s4()

    # 备选：原 v2 内嵌 6x3 immune-signature 表。数值直接抄自 S6A 图内标注（只有 P 值，图内无 FDR，
    # 故不设 FDR 列——不得由 P 推算后当作 FDR 报告）。
    optional5 = [["Immune cell signature", "Direction in PRRSV-infected PAMs",
                  "P (two-sided Mann-Whitney U)"],
                 ["Macrophage M1", "Up", "0.004"],
                 ["NK cell", "Down", "0.004"],
                 ["Treg", "Up", "0.008"],
                 ["Dendritic cell", "Up", "0.028"],
                 ["cDC1", "Up", "0.048"]]

    print("rows: S1=%d S2=%d S3A=%d S3B=%d S3C=%d S4=%d"
          % (len(s1), len(s2), len(s3a), len(s3b), len(s3c), len(s4)))
    build_xlsx(s1, s2, s3a, s3b, s3c, s4, optional5)
    build_docx(s1, s2, s3a, s3b, s3c, s4)
