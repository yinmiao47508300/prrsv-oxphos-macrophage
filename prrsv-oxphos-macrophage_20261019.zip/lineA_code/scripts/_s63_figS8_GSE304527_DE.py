# -*- coding: utf-8 -*-
"""Additional file 1: GSE304527 differential-expression panels.

Why this exists
---------------
Results paragraph [092]/[093] describes the population-level GSE304527 contrast
(log2FC = -0.312 for the 70 nuclear-encoded OXPHOS subunits, -0.060 for the 13
mitochondrially encoded ones, Mann-Whitney U = 777, P = 2.8e-5, POLRMT +1.43)
and then says "Differential-expression and enrichment results for this analysis
are shown in Additional file 1: Figures S2A, S2B, S3A and S3B".  Those four
figures are in fact the GSE22782 discovery panels (the S2A volcano is titled
"Volcano Plot: GSE22782 PRRSV vs Control" and the S2B heatmap has three CON and
three PRRSV columns).  There is currently no GSE304527 expression figure.

Two ways to resolve it:

  (i)  re-attribute the sentence in [093] to the discovery dataset, or
  (ii) add the two panels produced here as new supplementary panels
       (proposed numbering S8A and S8B) and cite those in [093].

This script produces (ii).

Source:  F:/Work Buudy/线A_分析/_GSE304527_DE.tsv
         (gene, module, log2FC, p_moderated, padj_moderated, ...)

Run:  python _s63_figS8_GSE304527_DE.py
"""
import csv
import os

import numpy as np
from scipy.stats import mannwhitneyu
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["savefig.dpi"] = 300

MM = 1 / 25.4
HERE = os.path.dirname(os.path.abspath(__file__))
DE = os.path.join(HERE, "_GSE304527_DE.tsv")
OUT = os.path.join(HERE, "figs_en")
os.makedirs(OUT, exist_ok=True)

C_UP = "#C0392B"
C_DOWN = "#2471A3"
C_NS = "#D5D8DC"
C_NUC = "#2471A3"
C_MT = "#C0392B"

NUCLEAR = ["CI", "CII", "CIII", "CIV", "CV"]

rec = []
with open(DE, encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        r["log2FC"] = float(r["log2FC"])
        r["p_moderated"] = float(r["p_moderated"])
        r["padj_moderated"] = float(r["padj_moderated"])
        rec.append(r)

fc = np.array([r["log2FC"] for r in rec])
p = np.array([r["p_moderated"] for r in rec])
q = np.array([r["padj_moderated"] for r in rec])

nuc = np.array([r["log2FC"] for r in rec if (r["module"] or "").strip() in NUCLEAR])
mt = np.array([r["log2FC"] for r in rec if (r["module"] or "").strip() == "MT"])
u_nuc, mw_p = mannwhitneyu(nuc, mt, alternative="two-sided")
uexact = u_nuc                      # U for the nuclear group
u_alt = nuc.size * mt.size - u_nuc  # U for the mitochondrial group
p_one = mw_p / 2.0                  # one-sided, direction nuclear < mitochondrial

print("nuclear-encoded OXPHOS subunits: n = %d   mean log2FC = %+.4f" % (nuc.size, nuc.mean()))
print("mitochondrially encoded       : n = %d   mean log2FC = %+.4f" % (mt.size, mt.mean()))
print("U(nuclear) = %.0f   U(mitochondrial) = %.0f" % (uexact, u_alt))
print("P two-sided = %.3g   P one-sided = %.3g" % (mw_p, p_one))
print("manuscript: log2FC -0.312 / -0.060 (P = 0.606);  n = 70 / 13;  U = 777, P = 2.8e-5")
print("  -> U = 777 is the mitochondrial-group statistic (70 x 13 - %.0f = %.0f)" % (uexact, u_alt))
print("  -> P = 2.8e-5 is the one-sided value; state this in the legend")
pol = [r for r in rec if r["gene"] == "POLRMT"]
if pol:
    print("POLRMT log2FC = %+.3f" % pol[0]["log2FC"])

# ---------------------------------------------------------------------------
fig = plt.figure(figsize=(180 * MM, 88 * MM))
axA = fig.add_axes([0.075, 0.155, 0.40, 0.735])
axB = fig.add_axes([0.585, 0.155, 0.385, 0.735])

# ---- A : volcano ---------------------------------------------------------
sig = (p < 0.05) & (np.abs(fc) >= 1)
axA.scatter(fc[~sig], -np.log10(p[~sig]), s=3.4, c=C_NS, linewidths=0,
            alpha=0.65, zorder=2, label="not significant")
axA.scatter(fc[sig & (fc > 0)], -np.log10(p[sig & (fc > 0)]), s=5.0, c=C_UP,
            linewidths=0, alpha=0.85, zorder=3, label="up (%d)" % int((sig & (fc > 0)).sum()))
axA.scatter(fc[sig & (fc < 0)], -np.log10(p[sig & (fc < 0)]), s=5.0, c=C_DOWN,
            linewidths=0, alpha=0.85, zorder=3, label="down (%d)" % int((sig & (fc < 0)).sum()))
for gname in ("POLRMT", "SDHC", "MRPL2"):
    hit = [r for r in rec if r["gene"] == gname]
    if hit:
        r0 = hit[0]
        axA.annotate(gname, (r0["log2FC"], -np.log10(r0["p_moderated"])),
                     xytext=(3, 3), textcoords="offset points", fontsize=6.6,
                     color="#1B2631")
axA.axvline(1, color="#7F8C8D", lw=0.55, ls="--")
axA.axvline(-1, color="#7F8C8D", lw=0.55, ls="--")
axA.axhline(-np.log10(0.05), color="#7F8C8D", lw=0.55, ls="--")
axA.set_xlabel("log$_2$ fold change (PRRSV vs mock)", fontsize=7.8)
axA.set_ylabel("$-$log$_{10}$ $P$", fontsize=7.8)
axA.set_xlim(-4.2, 4.2)
axA.tick_params(labelsize=7.0, width=0.7, length=2.4)
for sp in ("top", "right"):
    axA.spines[sp].set_visible(False)
axA.legend(loc="upper left", frameon=False, fontsize=6.8, handletextpad=0.3)
axA.set_title("A   GSE304527 PAMs: PRRSV-2 vs mock", fontsize=8.4,
              loc="left", fontweight="bold", pad=4)

# ---- B : OXPHOS subunit distributions -----------------------------------
parts = axB.violinplot([nuc, mt], positions=[0, 1], widths=0.62,
                       showextrema=False, showmedians=False)
for b, c in zip(parts["bodies"], [C_NUC, C_MT]):
    b.set_facecolor(c)
    b.set_alpha(0.32)
    b.set_edgecolor(c)
for i, (v, c) in enumerate([(nuc, C_NUC), (mt, C_MT)]):
    bp = axB.boxplot([v], positions=[i], widths=0.26, showfliers=False,
                     patch_artist=True,
                     medianprops=dict(color="black", lw=1.2),
                     whiskerprops=dict(color="#4D5656", lw=0.8),
                     capprops=dict(color="#4D5656", lw=0.8))
    bp["boxes"][0].set_facecolor(c)
    bp["boxes"][0].set_alpha(0.75)
    bp["boxes"][0].set_edgecolor("#34495E")
    rng = np.random.default_rng(7)
    axB.scatter(i + rng.uniform(-0.075, 0.075, v.size), v, s=9,
                facecolor="white", edgecolor="#2C3E50", lw=0.45, zorder=5)
axB.axhline(0, color="#7F8C8D", lw=0.6)
axB.set_xticks([0, 1])
axB.set_xticklabels(["Nuclear-encoded\n(n = %d)" % nuc.size,
                     "Mitochondrially encoded\n(n = %d)" % mt.size], fontsize=7.4)
axB.set_ylabel("log$_2$ fold change", fontsize=7.8)
axB.set_ylim(-2.2, 2.6)
axB.tick_params(axis="y", labelsize=7.0, width=0.7, length=2.4)
for sp in ("top", "right"):
    axB.spines[sp].set_visible(False)
axB.text(0.5, 0.94, "Mann-Whitney $U$ = %.0f\n$P$ = %.1e (one-sided)" % (u_alt, p_one),
         transform=axB.transAxes, ha="center", va="top", fontsize=7.2)
axB.set_title("B   OXPHOS subunits by genomic compartment", fontsize=8.4,
              loc="left", fontweight="bold", pad=4)

stem = "FigureS8_GSE304527_DE"
fig.savefig(os.path.join(OUT, stem + ".png"), dpi=300)
try:
    fig.savefig(os.path.join(OUT, stem + ".tiff"), dpi=300,
                pil_kwargs={"compression": "tiff_lzw"})
    print("\ntiff ok")
except Exception as e:                                     # pragma: no cover
    print("\nTIFF skipped:", e)
plt.close(fig)
print("written to", OUT)
