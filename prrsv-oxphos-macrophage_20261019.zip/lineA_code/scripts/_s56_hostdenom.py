# -*- coding: utf-8 -*-
"""D4b: 病毒 reads 稀释效应检验（关键自证）
问题: _s46_qc.py 的 nUMI = tot[cc] += v 对全部矩阵条目累加, 包含 27 条病毒 feature。
      -> 模块得分 log1p(sum_mod/nUMI*1e4) 在 viral+ 细胞中被病毒 reads 稀释,
         产生"viral+ 细胞所有宿主程序都偏低"的系统性假象(方向上支持我们的主结论)。
做法: 改用宿主分母 host_nUMI = nUMI − virAll 重算全部分数, 与旧口径逐模块对比。
输出: _step31_hostdenom.txt
"""
import gzip, os, io
import numpy as np
from scipy import stats

QC = r"F:\Work Buudy\线A_分析\GSE247257\qc"
D = r"F:\Work Buudy\线A_分析"
OUT = os.path.join(D, "_step31_hostdenom.txt")

MODS = [("OXNUC", "核编码OXPHOS"), ("MT", "MT编码13亚基"), ("CII", "复合体II(3/4)"),
        ("TCA", "TCA循环"), ("FAO", "脂肪酸氧化FAO"), ("MITOR", "线粒体核糖体"),
        ("BIOG", "mtDNA维持机器"), ("ISG", "抗病毒ISG")]

INF = {
    "GSM7886188": ("JA142", "3d"), "GSM7886189": ("JA142", "3d"), "GSM7886190": ("JA142", "3d"),
    "GSM7886199": ("JA142", "7d"), "GSM7886200": ("JA142", "7d"), "GSM7886201": ("JA142", "7d"),
    "GSM7886175": ("JA142", "14d"), "GSM7886176": ("JA142", "14d"), "GSM7886177": ("JA142", "14d"),
    "GSM7886184": ("JA142", "21d"), "GSM7886185": ("JA142", "21d"), "GSM7886186": ("JA142", "21d"),
    "GSM7886192": ("M8", "3d"), "GSM7886193": ("M8", "3d"), "GSM7886194": ("M8", "3d"),
    "GSM7886202": ("M8", "7d"), "GSM7886203": ("M8", "7d"), "GSM7886204": ("M8", "7d"),
    "GSM7886196": ("PJ10", "3d"), "GSM7886197": ("PJ10", "3d"), "GSM7886198": ("PJ10", "3d"),
    "GSM7886205": ("PJ10", "7d"), "GSM7886206": ("PJ10", "7d"), "GSM7886207": ("PJ10", "7d"),
}


def load(gsm):
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ix = {h: i for i, h in enumerate(hdr)}
        rows = [ln.rstrip("\n").split("\t") for ln in f]
    d = {"nUMI": np.array([float(r[ix["nUMI"]]) for r in rows]),
         "vir": np.array([float(r[ix["virAll"]]) for r in rows]),
         "mito": np.array([float(r[ix["pct_mito"]]) for r in rows]),
         "Mpos": np.array([int(r[ix["Mpos"]]) for r in rows])}
    for k, _ in MODS:
        d[k] = np.array([float(r[ix["sum_" + k]]) for r in rows])
    return d


def rbn(u, n1, n2):
    return 2.0 * u / (n1 * n2) - 1.0


def r_of(s, pos, neg):
    if pos.sum() < 10 or neg.sum() < 10:
        return None
    u, p = stats.mannwhitneyu(s[pos], s[neg], alternative="two-sided")
    return rbn(u, pos.sum(), neg.sum()), p


def main():
    L = []
    W = L.append
    W("=" * 106)
    W("【D4b 病毒 reads 稀释效应检验】旧口径 nUMI（含病毒 reads） vs 新口径 host_nUMI（宿主 reads）")
    W("=" * 106)
    W("若两口径效应量接近 -> 主结论不是病毒 reads 稀释造成的假象；若相差悬殊 -> 必须改用宿主分母。")
    W("")
    W(f"{'GSM':<13}{'毒株':>7}{'时点':>5}{'n_pos':>7}{'病毒占 nUMI 中位%':>19}"
      f"{'病毒占 nUMI 均值%':>19}")
    fracs = []
    store = {}
    for g, (st, dp) in INF.items():
        a = load(g)
        gate = (a["Mpos"] >= 1) & (a["mito"] <= 15)
        pos = gate & (a["vir"] >= 10)
        neg = gate & (a["vir"] == 0)
        if pos.sum() < 10 or neg.sum() < 10:
            continue
        fr = a["vir"][pos] / np.maximum(a["nUMI"][pos], 1) * 100.0
        fracs.extend(fr.tolist())
        r_old, r_new = {}, {}
        host = np.maximum(a["nUMI"] - a["vir"], 1.0)
        for k, _ in MODS:
            s_old = np.log1p(a[k] / np.maximum(a["nUMI"], 1) * 1e4)
            s_new = np.log1p(a[k] / host * 1e4)
            ro = r_of(s_old, pos, neg)
            rn = r_of(s_new, pos, neg)
            if ro and rn:
                r_old[k], r_new[k] = ro[0], rn[0]
        store[g] = (st, dp, int(pos.sum()), r_old, r_new)
        W(f"{g:<13}{st:>7}{dp:>5}{int(pos.sum()):>7}{np.median(fr):>19.4f}{fr.mean():>19.4f}")

    W("")
    W("--- 模块级汇总对比 ---")
    W(f"{'模块':<18}{'旧口径 均值r':>14}{'宿主口径 均值r':>16}{'差值':>10}{'旧 p':>12}{'宿主 p':>12}{'差值':>10}")
    for k, name in MODS:
        ro = np.array([store[g][3][k] for g in store if k in store[g][3]])
        rn = np.array([store[g][4][k] for g in store if k in store[g][4]])
        if len(ro) < 3:
            continue
        to, po = stats.ttest_1samp(ro, 0.0)
        tn, pn = stats.ttest_1samp(rn, 0.0)
        W(f"{name:<18}{ro.mean():>+14.4f}{rn.mean():>+16.4f}{rn.mean() - ro.mean():>+10.4f}"
          f"{po:>12.5f}{pn:>12.5f}{np.abs(rn.mean()) - np.abs(ro.mean()):>+10.4f}")

    W("")
    if fracs:
        fa = np.array(fracs)
        W(f"viral+ 细胞中病毒 reads 占 nUMI 比例: 中位 {np.median(fa):.3f}%  均值 {fa.mean():.3f}%  "
          f"P90 {np.percentile(fa, 90):.3f}%  P99 {np.percentile(fa, 99):.3f}%  最大 {fa.max():.3f}%")
        W("解 读: 中位占比 <1% 时, 稀释对分数的中位差影响约 1e-2 量级, 远小于观测效应量(0.2-0.4),")
        W("        故旧口径与宿主口径结论一致即证明主结论稳健; 但仍建议正文改用宿主分母口径报告。")
    else:
        W("无足够 viral+ 细胞")

    with io.open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("done")


if __name__ == "__main__":
    main()
