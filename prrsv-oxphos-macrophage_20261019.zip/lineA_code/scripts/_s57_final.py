# -*- coding: utf-8 -*-
"""线A 最终分析（统一修正口径）=== 权威版本 ===
三项修正同时落实:
  ① 宿主分母: host_nUMI = nUMI − virAll（排除 27 条病毒 feature 对测序深度的占用）
  ② 宿主 pct_mito 门控: host_pct_mito = sum_MT / host_nUMI × 100 ≤ 15
  ③ 深度匹配: 样内 nUMI 十分位分层, 层内比较
设计:
  比较A（固有）= 样本内 viral+(v>=10) vs viral-(v=0)
  比较B（旁分泌）= 感染组 viral- vs 同时点 3 只阴性对照
输出: _step32_final.txt, _final_A.csv, _final_B.csv, _final_summary.csv,
      _final_depthmatch.csv, _final_counts.csv
"""
import gzip, os, io, csv
import numpy as np
from scipy import stats

QC = r"F:\Work Buudy\线A_分析\GSE247257\qc"
D = r"F:\Work Buudy\线A_分析"

MODS = [("OXNUC", "核编码OXPHOS"), ("MT", "MT编码13亚基"), ("CII", "复合体II(3/4)"),
        ("TCA", "TCA循环"), ("FAO", "脂肪酸氧化FAO"), ("MITOR", "线粒体核糖体"),
        ("BIOG", "mtDNA维持机器"), ("ISG", "抗病毒ISG")]

INF = {
    "GSM7886188": ("JA142", "3d"), "GSM7886189": ("JA142", "3d"), "GSM7886190": ("JA142", "3d"),
    "GSM7886199": ("JA142", "7d"), "GSM7886200": ("JA142", "7d"), "GSM7886201": ("JA142", "7d"),
    "GSM7886175": ("JA142", "14d"), "GSM7886176": ("JA142", "14d"), "GSM7886177": ("JA142", "14d"),
    "GSM7886184": ("JA142", "21d"), "GSM7886185": ("JA142", "21d"), "GSM7886186": ("JA142", "21d"),
    "GSM7886192": ("M8", "3d"), "GSM7886193": ("M8", "3d"), "GSM7886194": ("M8", "3d"),
    "GSM7886202": ("M8", "7d"), "GSM7886203": ("M8", "7d"), "GSM7886204": ("M8", "7d"),
    "GSM7886196": ("PJ10", "3d"), "GSM7886197": ("PJ10", "3d"), "GSM7886198": ("PJ10", "3d"),
    "GSM7886205": ("PJ10", "7d"), "GSM7886206": ("PJ10", "7d"), "GSM7886207": ("PJ10", "7d"),
}
CTRL = {
    "3d": ["GSM7886187", "GSM7886191", "GSM7886195"],
    "7d": ["GSM7886208", "GSM7886209", "GSM7886210"],
    "14d": ["GSM7886178", "GSM7886179", "GSM7886180"],
    "21d": ["GSM7886181", "GSM7886182", "GSM7886183"],
}


def load(gsm):
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ix = {h: i for i, h in enumerate(hdr)}
        rows = [ln.rstrip("\n").split("\t") for ln in f]
    d = {"nUMI": np.array([float(r[ix["nUMI"]]) for r in rows]),
         "vir": np.array([float(r[ix["virAll"]]) for r in rows]),
         "Mpos": np.array([int(r[ix["Mpos"]]) for r in rows])}
    for k, _ in MODS:
        d[k] = np.array([float(r[ix["sum_" + k]]) for r in rows])
    d["host"] = np.maximum(d["nUMI"] - d["vir"], 1.0)
    d["hmito"] = d["MT"] / d["host"] * 100.0              # 宿主分母 pct_mito
    d["gate"] = (d["Mpos"] >= 1) & (d["hmito"] <= 15)
    d["S"] = {k: np.log1p(d[k] / d["host"] * 1e4) for k, _ in MODS}   # 宿主分母得分
    return d


def rbn(u, n1, n2):
    return 2.0 * u / (n1 * n2) - 1.0


def mwu_r(x, y):
    if len(x) < 10 or len(y) < 10:
        return None, None
    u, p = stats.mannwhitneyu(x, y, alternative="two-sided")
    return rbn(u, len(x), len(y)), float(p)


def depth_matched(s, nU, pos, neg, min_pos=5, min_neg=50):
    """样内 nUMI 十分位分层, 层内 (median pos − median neg), 按 pos 细胞数加权"""
    edges = np.unique(np.percentile(nU, np.arange(0, 101, 10)))
    if len(edges) < 3:
        return np.nan, 0
    bins = np.digitize(nU, edges[1:-1], right=False)
    tw, ts, k = 0.0, 0.0, 0
    for b in np.unique(bins):
        mp = pos & (bins == b)
        mn = neg & (bins == b)
        if mp.sum() >= min_pos and mn.sum() >= min_neg:
            ts += (np.median(s[mp]) - np.median(s[mn])) * mp.sum()
            tw += mp.sum()
            k += 1
    return (ts / tw if tw > 0 else np.nan), k


def main():
    L = []
    W = L.append
    W("=" * 112)
    W("【线A 最终分析 · 统一修正口径】宿主分母 + 宿主 pct_mito 门控 + 深度匹配")
    W("=" * 112)
    W("核心问题: PRRSV 对巨噬细胞 OXPHOS 的重编程是细胞内在, 还是旁分泌群体效应?")
    W("口径: host_nUMI = nUMI − 病毒reads;  gate = Mpos>=1 且 sum_MT/host_nUMI<=15%;")
    W("      score = log1p(模块UMI / host_nUMI × 1e4);  效应量 = rank-biserial r")
    W("")

    # ---------- 阴性对照池 ----------
    ctrlS = {}
    for dp, gs in CTRL.items():
        acc = {k: [] for k, _ in MODS}
        n = 0
        for g in gs:
            a = load(g)
            m = a["gate"]
            n += int(m.sum())
            for k, _ in MODS:
                acc[k].append(a["S"][k][m])
        ctrlS[dp] = ({k: np.concatenate(v) for k, v in acc.items()}, n)

    # ---------- 计数表 ----------
    rowsC = [["gsm", "group", "strain", "dpi", "n_gate", "n_pos", "n_neg",
              "host_numi_med", "vir_frac_med_pct", "vir_max"]]

    RA, RB, RD, RS = [], [], [], []
    store = {}
    for g, (st, dp) in INF.items():
        a = load(g)
        gt = a["gate"]
        pos = gt & (a["vir"] >= 10)
        neg = gt & (a["vir"] == 0)
        vf = a["vir"][gt] / np.maximum(a["nUMI"][gt], 1) * 100.0
        rowsC.append([g, "Infected", st, dp, int(gt.sum()), int(pos.sum()), int(neg.sum()),
                      f"{np.median(a['host'][gt]):.0f}",
                      f"{np.median(vf):.3f}" if len(vf) else "0", f"{a['vir'].max():.0f}"])
        rec = {"st": st, "dp": dp, "npos": int(pos.sum()), "nneg": int(neg.sum()), "A": {}, "B": {}, "D": {}}
        for k, _ in MODS:
            s = a["S"][k]
            if pos.sum() >= 10 and neg.sum() >= 10:
                r, p = mwu_r(s[pos], s[neg])
                rec["A"][k] = (r, p)
                RA.append([g, st, dp, k, f"{r:.6f}", f"{p:.6e}", int(pos.sum()), int(neg.sum())])
                md, kb = depth_matched(s, a["host"], pos, neg)
                rec["D"][k] = (md, kb)
                RD.append([g, st, dp, k, f"{np.median(s[pos]) - np.median(s[neg]):.6f}",
                           ("" if np.isnan(md) else f"{md:.6f}"), kb])
            cs, nc = ctrlS[dp]
            if neg.sum() >= 10 and nc >= 10:
                r, p = mwu_r(s[neg], cs[k])
                rec["B"][k] = (r, p)
                RB.append([g, st, dp, k, f"{r:.6f}", f"{p:.6e}", int(neg.sum()), nc])
        store[g] = rec

    for dp, gs in CTRL.items():
        for g in gs:
            a = load(g)
            gt = a["gate"]
            rowsC.append([g, "Negative", "Negative", dp, int(gt.sum()), 0, int(gt.sum()),
                          f"{np.median(a['host'][gt]):.0f}", "0", f"{a['vir'].max():.0f}"])

    # ---------- 汇总 ----------
    W("--- 比较 A（固有）：样本内 viral+ vs viral-（宿主分母得分）---")
    W(f"{'模块':<18}{'n样本':>7}{'均值 r':>11}{'中位 r':>11}{'同向数':>9}{'t检验 p':>12}{'判读':>20}")
    sumA, sumB, sumD = {}, {}, {}
    for k, name in MODS:
        v = np.array([store[g]["A"][k][0] for g in store if k in store[g]["A"]])
        if len(v) >= 3:
            t, p = stats.ttest_1samp(v, 0.0)
            conc = sum(1 for x in v if np.sign(x) == np.sign(v.mean()))
            verd = "viral+ 显著高" if (p < 0.05 and v.mean() > 0) else \
                   ("viral+ 显著低" if (p < 0.05 and v.mean() < 0) else "无方向")
            sumA[k] = (len(v), v.mean(), float(np.median(v)), f"{conc}/{len(v)}", float(p), verd)
            W(f"{name:<18}{len(v):>7}{v.mean():>+11.4f}{np.median(v):>+11.4f}"
              f"{conc:>6}/{len(v):<3}{p:>12.5f}{verd:>20}")
    W("")
    W("--- 比较 B（旁分泌）：感染组旁观 vs 同时点阴性对照 ---")
    W(f"{'模块':<18}{'n样本':>7}{'均值 r':>11}{'中位 r':>11}{'同向数':>9}{'t检验 p':>12}{'判读':>20}")
    for k, name in MODS:
        v = np.array([store[g]["B"][k][0] for g in store if k in store[g]["B"]])
        if len(v) >= 3:
            t, p = stats.ttest_1samp(v, 0.0)
            conc = sum(1 for x in v if np.sign(x) == np.sign(v.mean()))
            verd = "旁观显著高" if (p < 0.05 and v.mean() > 0) else \
                   ("旁观显著低" if (p < 0.05 and v.mean() < 0) else "无方向")
            sumB[k] = (len(v), v.mean(), float(np.median(v)), f"{conc}/{len(v)}", float(p), verd)
            W(f"{name:<18}{len(v):>7}{v.mean():>+11.4f}{np.median(v):>+11.4f}"
              f"{conc:>6}/{len(v):<3}{p:>12.5f}{verd:>20}")
    W("")
    W("--- 深度匹配（宿主分母得分 + nUMI 十分位分层）---")
    W(f"{'模块':<18}{'n样本':>7}{'均值 匹配Δ':>14}{'同向数':>9}{'t检验 p':>12}{'判读':>20}")
    for k, name in MODS:
        v = np.array([store[g]["D"][k][0] for g in store
                      if k in store[g]["D"] and not np.isnan(store[g]["D"][k][0])])
        if len(v) >= 3:
            t, p = stats.ttest_1samp(v, 0.0)
            conc = sum(1 for x in v if np.sign(x) == np.sign(v.mean()))
            verd = "匹配后仍升" if (p < 0.05 and v.mean() > 0) else \
                   ("匹配后仍降" if (p < 0.05 and v.mean() < 0) else "无方向")
            sumD[k] = (len(v), v.mean(), f"{conc}/{len(v)}", float(p), verd)
            W(f"{name:<18}{len(v):>7}{v.mean():>+14.4f}{conc:>6}/{len(v):<3}{p:>12.5f}{verd:>20}")
    W("")
    W("--- 2×2 判别（以比较 A / 比较 B 的均值 r 定位）---")
    W(f"{'模块':<18}{'A 均值 r':>11}{'A p':>11}{'B 均值 r':>11}{'B p':>11}{'落点':>26}")
    for k, name in MODS:
        if k not in sumA or k not in sumB:
            continue
        ar, ap = sumA[k][1], sumA[k][4]
        br, bp = sumB[k][1], sumB[k][4]
        a_sig, b_sig = ap < 0.05, bp < 0.05
        if a_sig and b_sig:
            loc = "固有 + 旁分泌双成分" if np.sign(ar) == np.sign(br) else "双成分（方向分离）"
        elif a_sig:
            loc = "纯固有"
        elif b_sig:
            loc = "纯旁分泌"
        else:
            loc = "无效应"
        W(f"{name:<18}{ar:>+11.4f}{ap:>11.5f}{br:>+11.4f}{bp:>11.5f}{loc:>26}")

    # ---------- B 的样本敏感性: 仅取单细胞层可证感染的样本 ----------
    W("")
    W("--- 比较 B 样本敏感性：仅取 单细胞层可证感染（n_pos>=10）的样本 ---")
    W(f"{'模块':<18}{'B 全样本 均值 r':>17}{'B 可证感染子集 均值 r':>22}{'子集 n':>8}{'子集 t 检验 p':>15}")
    for k, name in MODS:
        sub = np.array([store[g]["B"][k][0] for g in store
                        if k in store[g]["B"] and store[g]["npos"] >= 10])
        full = np.array([store[g]["B"][k][0] for g in store if k in store[g]["B"]])
        if len(sub) >= 3:
            t, p = stats.ttest_1samp(sub, 0.0)
            W(f"{name:<18}{full.mean():>+17.4f}{sub.mean():>+22.4f}{len(sub):>8}{p:>15.5f}")

    # ---------- 模块级 BH-FDR（8 个模块内的多重校正） ----------
    def bh(ps):
        ps = np.asarray(ps, dtype=float)
        o = np.argsort(ps)
        m = len(ps)
        q = np.empty(m)
        prev = 1.0
        for rank in range(m - 1, -1, -1):
            i = o[rank]
            val = ps[i] * m / (rank + 1)
            prev = min(prev, val)
            q[i] = prev
        return q

    W("")
    W("--- 模块级 BH-FDR（在 8 个模块内校正；动物级推断）---")
    for tag, keyfield, filt in [("比较 A（固有，12 样本）", "A", lambda g: True),
                                ("比较 B（旁分泌，12 个可证感染样本）", "B",
                                 lambda g: store[g]["npos"] >= 10)]:
        names, ps = [], []
        for k, name in MODS:
            v = np.array([store[g][keyfield][k][0] for g in store
                          if k in store[g][keyfield] and filt(g)])
            if len(v) >= 3:
                t, p = stats.ttest_1samp(v, 0.0)
                names.append(name); ps.append(float(p))
        if not ps:
            continue
        q = bh(ps)
        W(f"  [{tag}]  通过 BH-FDR<0.05 的模块数 = {int((q < 0.05).sum())}/{len(ps)}")
        for nm, p, qq in sorted(zip(names, ps, q), key=lambda z: z[1]):
            W(f"      {nm:<18} p={p:.5f}   q={qq:.5f}   {'通过' if qq < 0.05 else '未通过'}")

    # 分组汇总（核编码 OXPHOS 与 MT）
    W("")
    W("--- 分组汇总（比较 A 均值 r，毒株×时点）---")
    grp = {}
    for g, rec in store.items():
        if "OXNUC" not in rec["A"]:
            continue
        key = (rec["st"], rec["dp"])
        grp.setdefault(key, []).append(rec)
    order = [("JA142", "7d"), ("JA142", "14d"), ("PJ10", "3d"), ("PJ10", "7d"),
             ("JA142", "3d"), ("JA142", "21d"), ("M8", "3d"), ("M8", "7d")]
    W(f"{'毒株×时点':<14}{'n':>4}" + "".join(f"{n:>18}" for _, n in MODS))
    for key in order:
        if key not in grp:
            continue
        rs = grp[key]
        cells = [f"{np.mean([r['A'][k][0] for r in rs]):>+18.4f}" if all(k in r["A"] for r in rs)
                 else f"{'—':>18}" for k, _ in MODS]
        W(f"{key[0]+' '+key[1]:<14}{len(rs):>4}" + "".join(cells))

    # ---------- CSV ----------
    def wcsv(fn, head, rows):
        with io.open(os.path.join(D, fn), "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(head)
            for r in rows:
                w.writerow(r)
    wcsv("_final_A.csv", ["gsm", "strain", "dpi", "module", "r", "p", "n_pos", "n_neg"], RA)
    wcsv("_final_B.csv", ["gsm", "strain", "dpi", "module", "r", "p", "n_inf_neg", "n_ctrl"], RB)
    wcsv("_final_depthmatch.csv", ["gsm", "strain", "dpi", "module", "crude_delta", "matched_delta", "n_bins"], RD)
    wcsv("_final_counts.csv", rowsC[0], rowsC[1:])
    wcsv("_final_summary.csv",
         ["module", "A_n", "A_mean_r", "A_med_r", "A_conc", "A_p", "B_n", "B_mean_r", "B_med_r",
          "B_conc", "B_p", "D_n", "D_mean_matched", "D_conc", "D_p"],
         [[k, sumA.get(k, ("",) * 6)[0], f"{sumA[k][1]:.6f}" if k in sumA else "",
           f"{sumA[k][2]:.6f}" if k in sumA else "", sumA[k][3] if k in sumA else "",
           f"{sumA[k][4]:.6f}" if k in sumA else "",
           sumB.get(k, ("",) * 6)[0], f"{sumB[k][1]:.6f}" if k in sumB else "",
           f"{sumB[k][2]:.6f}" if k in sumB else "", sumB[k][3] if k in sumB else "",
           f"{sumB[k][4]:.6f}" if k in sumB else "",
           sumD.get(k, ("",) * 5)[0], f"{sumD[k][1]:.6f}" if k in sumD else "",
           sumD[k][2] if k in sumD else "", f"{sumD[k][3]:.6f}" if k in sumD else ""]
          for k, _ in MODS])

    with io.open(os.path.join(D, "_step32_final.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("done")


if __name__ == "__main__":
    main()
