# -*- coding: utf-8 -*-
"""Additional file 1: new tables for statements that are narrated in the text
but currently carry no table.

  Table S5  all 18 immune signature scores, P and Benjamini-Hochberg q
            (the existing TableS5_optional sheet lists only 5 and no q)
  Table S6  normalisation-denominator sensitivity for all eight modules
            (P048 / P110 / P114)
  Table S7  leave-one-time-point-out sensitivity of the
            microenvironment-associated comparison (P078)

Writes one .xlsx with three sheets and prints every number so it can be
checked against the manuscript.

Run:  python _s62_tables_S5_S6_S7.py
"""
import csv
import gzip
import os

import numpy as np
from scipy.stats import mannwhitneyu, ttest_1samp, spearmanr
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
QC = os.path.join(HERE, "GSE247257", "qc")
REF = os.path.join(HERE, "ref", "tx2gene_symbol.tsv")
PAM = r"F:/Work Buudy/GSE304527_PAM.csv.gz"
OUTX = os.path.join(HERE, "_work", "线A_新增补充表S5-S7.xlsx")
os.makedirs(os.path.dirname(OUTX), exist_ok=True)

MODULES = [("OXNUC", "sum_OXNUC", "Nuclear-encoded OXPHOS"),
           ("MT", "sum_MT", "Mitochondrially encoded subunits"),
           ("CII", "sum_CII", "Complex II"),
           ("TCA", "sum_TCA", "TCA cycle"),
           ("FAO", "sum_FAO", "Fatty-acid beta-oxidation"),
           ("MITOR", "sum_MITOR", "Mitochondrial ribosome"),
           ("BIOG", "sum_BIOG", "mtDNA maintenance"),
           ("ISG", "sum_ISG", "Antiviral / ISG response")]

meta = {r["gsm"]: r for r in csv.DictReader(
    open(os.path.join(HERE, "_final_counts.csv"), encoding="utf-8-sig"))}
EVALUABLE = sorted(g for g, m in meta.items() if int(float(m["n_pos"])) >= 10)
print("evaluable libraries (>=10 viral-positive cells):", len(EVALUABLE))


def rank_biserial(a, b):
    """r = 2U/(n1 n2) - 1, U from the Mann-Whitney statistic (a vs b)."""
    u, _ = mannwhitneyu(a, b, alternative="two-sided")
    return 2.0 * u / (len(a) * len(b)) - 1.0


def bh(pvals):
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    n = len(pvals)
    q = [0.0] * n
    run = 1.0
    for k in range(n - 1, -1, -1):
        i = order[k]
        run = min(run, pvals[i] * n / (k + 1))
        q[i] = run
    return q


def one_sample_p(vals):
    return float(ttest_1samp(vals, 0.0, alternative="two-sided").pvalue)


# ===========================================================================
# Table S5  immune signature scores
# ===========================================================================
IMMUNE_SETS = {
    "T_cell": ["CD3D", "CD3E", "CD3G", "CD28", "LCK", "CD4", "CD8A", "CD8B"],
    "CD8_T": ["CD8A", "CD8B", "GZMB", "PRF1", "NKG7", "CCL5", "GZMA"],
    "Treg": ["FOXP3", "IL10", "TGFB1", "CTLA4", "IKZF2", "TNFRSF18"],
    "B_cell": ["CD19", "MS4A1", "CD79A", "CD79B", "CD22", "BLK", "BANK1", "PAX5"],
    "NK_cell": ["NKG7", "KLRD1", "KLRK1", "KLRC1", "NCR1", "NCR3", "FCGR3A"],
    "Monocyte": ["CD14", "LYZ", "CSF1R", "FCGR3A", "CCR2", "S100A8", "S100A9"],
    "Macrophage_M1": ["TNF", "IL1B", "IL6", "CXCL8", "CXCL10", "CCL2", "CCL3", "NOS2"],
    "Macrophage_M2": ["CD163", "MRC1", "MSR1", "ARG1"],
    "DC": ["CD1C", "CLEC10A", "ITGAX", "CD80", "CD86", "HLA-DRA", "HLA-DRB1"],
    "pDC": ["IRF7", "TLR7", "TLR9", "CLEC4C", "LILRA4"],
    "cDC1": ["XCR1", "BATF3", "IRF8", "CLEC9A"],
    "cDC2": ["CD1C", "CLEC10A", "FCER1A", "IRF4"],
    "Neutrophil": ["CXCR2", "CXCR1", "S100A8", "S100A9", "CSF3R", "FCGR3B", "CXCL8"],
    "Eosinophil": ["SIGLEC8", "CCR3", "IL5RA", "PRG2", "RNASE2", "RNASE3"],
    "Plasma_cell": ["PRDM1", "XBP1", "IRF4", "CD38", "SDC1", "TNFRSF17"],
    "Th1": ["TBX21", "IFNG", "IL12RB2", "STAT4"],
    "Th2": ["GATA3", "IL4", "IL5", "IL13", "STAT6"],
    "Th17": ["RORC", "IL17A", "IL17F", "IL23R", "CCR6"],
}
MOCK = ["PAM_Mock_3", "PAM_Mock_4", "PAM_Mock_6", "PAM_Mock_7"]
PRRSV = ["PAM_134_3", "PAM_134_4", "PAM_134_6", "PAM_134_7",
         "PAM_174_3", "PAM_174_4", "PAM_174_6", "PAM_174_7"]
ALL = MOCK + PRRSV

want = set([s for v in IMMUNE_SETS.values() for s in v])
sym2tx = {}
for r in csv.DictReader(open(REF, encoding="utf-8", errors="replace"), delimiter="\t"):
    g = (r["gene_name"] or "").strip()
    if g in want:
        sym2tx.setdefault(g, []).append(r["transcript_id"])
with gzip.open(PAM, "rt", encoding="utf-8", errors="replace") as f:
    rd = csv.reader(f, delimiter="\t")
    header = next(rd)
    rows = {r[0]: np.array([float(x) for x in r[1:]]) for r in rd if r}
cols = header[1:]
idx = [cols.index(c) for c in ALL]
mi = [ALL.index(c) for c in MOCK]
pi = [ALL.index(c) for c in PRRSV]


def gene_expr(s):
    tx = [rows[t] for t in sym2tx.get(s, []) if t in rows]
    return np.mean(tx, axis=0) if tx else None


scores = {}
for ct, mk in IMMUNE_SETS.items():
    v = [gene_expr(m)[idx] for m in mk if gene_expr(m) is not None]
    if v:
        scores[ct] = np.mean(v, axis=0)

t5 = []
for ct, v in scores.items():
    u, p = mannwhitneyu(v[pi], v[mi], alternative="two-sided")
    t5.append([ct, float(v[mi].mean()), float(v[pi].mean()),
               float(v[pi].mean() - v[mi].mean()), float(p)])
qs = bh([r[4] for r in t5])
for r, q in zip(t5, qs):
    r.append(q)
t5.sort(key=lambda r: r[4])
print("\n=== Table S5 : 18 immune signatures ===")
print("%-16s %9s %9s %9s %9s %9s" % ("signature", "mock", "PRRSV", "delta", "P", "q_BH"))
for r in t5:
    print("%-16s %9.2f %9.2f %+9.2f %9.4f %9.4f %s"
          % (r[0], r[1], r[2], r[3], r[4], r[5],
             "q<0.05" if r[5] < 0.05 else ("nominal" if r[4] < 0.05 else "")))

# ===========================================================================
# Table S6  denominator sensitivity (comparison A)
# ===========================================================================
percell = {}
for g in EVALUABLE:
    p = os.path.join(QC, g + "_percell.tsv.gz")
    if not os.path.exists(p):
        continue
    n, v, m = [], [], {col: [] for _, col, _ in MODULES}
    with gzip.open(p, "rt", encoding="utf-8", errors="replace") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            nu = float(r["nUMI"])
            vir = float(r["virAll"])
            h = max(nu - vir, 1.0)
            # gated-macrophage definition that reproduces _final_counts.csv
            # exactly for all 36 libraries
            if float(r["nGene"]) < 200 or nu <= 0:
                continue
            if float(r["sum_MT"]) / h * 100.0 > 15.0:
                continue
            if int(float(r["Mpos"])) < 1:
                continue
            n.append(nu)
            v.append(vir)
            for _, col, _ in MODULES:
                m[col].append(float(r[col]))
    percell[g] = (np.array(n), np.array(v), {k: np.array(x) for k, x in m.items()})

t6 = []
for key, col, name in MODULES:
    rt, rh = [], []
    for g in EVALUABLE:
        if g not in percell:
            continue
        n, v, m = percell[g]
        pos = v >= 10
        neg = v == 0
        if pos.sum() < 10 or neg.sum() < 10:
            continue
        x = m[col]
        st = np.log1p(x / n * 1e4)
        sh = np.log1p(x / np.maximum(n - v, 1.0) * 1e4)
        rt.append(rank_biserial(st[pos], st[neg]))
        rh.append(rank_biserial(sh[pos], sh[neg]))
    t6.append([key, name, len(rt), float(np.mean(rt)), one_sample_p(rt),
               float(np.mean(rh)), one_sample_p(rh)])

print("\n=== Table S6 : denominator sensitivity, comparison A ===")
print("%-7s %-32s %4s %11s %10s %11s %10s"
      % ("module", "name", "n", "r(total)", "P", "r(host)", "P"))
for r in t6:
    print("%-7s %-32s %4d %11.4f %10.4f %11.4f %10.4f"
          % (r[0], r[1], r[2], r[3], r[4], r[5], r[6]))
print("manuscript: OXNUC -0.4364 -> -0.3934 ; TCA -0.0710 -> +0.0044")

# viral-fraction summary inside viral-positive cells
fr = []
for g in EVALUABLE:
    if g not in percell:
        continue
    n, v, _ = percell[g]
    sel = v >= 10
    fr.append(np.where(n[sel] > 0, v[sel] / n[sel] * 100.0, 0.0))
fr = np.concatenate(fr)
vfs = [float(np.median(fr)), float(np.mean(fr)),
       float(np.percentile(fr, 90)), float(fr.max())]
print("\nviral fraction of total nUMI in viral-positive cells: "
      "median %.2f%%  mean %.2f%%  P90 %.2f%%  max %.2f%%"
      % tuple(vfs))
print("manuscript: median 1.43%, mean 5.90%, P90 18.5%, max 45.2%")

# ===========================================================================
# Table S7  leave-one-time-point-out, comparison B
# ===========================================================================
B = list(csv.DictReader(open(os.path.join(HERE, "_final_B.csv"), encoding="utf-8-sig")))
B = [r for r in B if r["gsm"] in EVALUABLE]
dpi_of = {g: meta[g]["dpi"] for g in EVALUABLE}
timepoints = sorted(set(dpi_of.values()))
print("\n=== Table S7 : leave-one-time-point-out (comparison B) ===")
print("time points present: %s" % ", ".join(timepoints))

t7 = []
for drop in timepoints + ["none"]:
    keep = [g for g in EVALUABLE if dpi_of[g] != drop]
    ps, means, ns = [], [], []
    for key, _, name in MODULES:
        vals = [float(r["r"]) for r in B if r["module"] == key and r["gsm"] in keep]
        if len(vals) < 3:
            ps.append(float("nan")); means.append(float("nan")); ns.append(len(vals))
            continue
        means.append(float(np.mean(vals)))
        ps.append(one_sample_p(vals))
        ns.append(len(vals))
    qq = bh([p if not np.isnan(p) else 1.0 for p in ps])
    lab = "all time points" if drop == "none" else "omit %s" % drop
    print("\n%s   (n libraries = %s)" % (lab, ns[0]))
    for (key, _, name), mn, p, q in zip(MODULES, means, ps, qq):
        print("   %-7s %+8.4f  P = %8.4f   q = %8.4f  %s"
              % (key, mn, p, q, "q<0.05" if q < 0.05 else ""))
        t7.append([lab, key, name, len(keep) if key == "OXNUC" else "",
                   mn, p, q])

# ===========================================================================
# write workbook
# ===========================================================================
wb = openpyxl.Workbook()
BOLD = Font(bold=True)
FILL = PatternFill("solid", fgColor="D9E1F2")
WIDTHS = [24, 30, 14, 14, 14, 14, 14, 14]


def sheet(title, header, data, widths=None):
    ws = wb.create_sheet(title)
    ws.append(header)
    for c in ws[1]:
        c.font = BOLD
        c.fill = FILL
    for row in data:
        ws.append(row)
    for i, w in enumerate(widths or WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"
    return ws


del wb["Sheet"]
sheet("TableS5_immune18",
      ["Immune signature", "Mock mean", "PRRSV mean", "Delta",
       "P (Mann-Whitney)", "q (BH, 18 tests)"],
      [[r[0], round(r[1], 4), round(r[2], 4), round(r[3], 4),
        float("%.6g" % r[4]), float("%.6g" % r[5])] for r in t5],
      [22, 12, 12, 12, 18, 18])
sheet("TableS6_denominator",
      ["Module", "Module name", "Libraries (n)",
       "Mean rank-biserial r (total UMI denominator)", "P",
       "Mean rank-biserial r (host UMI denominator)", "P"],
      [[r[0], r[1], r[2], round(r[3], 4), float("%.6g" % r[4]),
        round(r[5], 4), float("%.6g" % r[6])] for r in t6],
      [10, 32, 14, 34, 12, 34, 12])
ws = sheet("TableS6b_viral_fraction",
           ["statistic", "viral fraction of total nUMI (%)"],
           [["median", round(vfs[0], 2)], ["mean", round(vfs[1], 2)],
            ["90th percentile", round(vfs[2], 2)], ["maximum", round(vfs[3], 2)]],
           [22, 34])
sheet("TableS7_LOTO",
      ["Analysis", "Module", "Module name", "Libraries (n)",
       "Mean rank-biserial r", "P", "q (BH, 8 modules)"],
      [[r[0], r[1], r[2], r[3],
        (round(r[4], 4) if r[4] == r[4] else "n.d."),
        (float("%.6g" % r[5]) if r[5] == r[5] else "n.d."),
        (float("%.6g" % r[6]) if r[6] == r[6] else "n.d.")] for r in t7],
      [18, 10, 32, 14, 22, 14, 18])
wb.save(OUTX)
print("\nwritten", OUTX)
