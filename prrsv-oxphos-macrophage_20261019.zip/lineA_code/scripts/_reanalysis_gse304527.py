# -*- coding: utf-8 -*-
"""GSE304527 样本级模块分数重分析（修复 gene-wise Mann-Whitney 伪重复）"""
import gzip, os, io, csv
import numpy as np
from scipy import stats

D = r"F:/Work Buudy/线A_分析"
DE = os.path.join(D, "_GSE304527_DE.tsv")
REF = os.path.join(D, "ref", "tx2gene_symbol.tsv")
PAM = r"F:/Work Buudy/GSE304527_PAM.csv.gz"

# 1. 基因 -> 模块（nuclear 70 = CI+CII+CIII+CIV+CV；MT 13）
nuc_genes, mt_genes = set(), set()
with open(DE, encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        mod = (r["module"] or "").strip()
        g = r["gene"].strip()
        if mod == "MT": mt_genes.add(g)
        elif mod in ("CI","CII","CIII","CIV","CV"): nuc_genes.add(g)
print("nuclear genes =", len(nuc_genes), " MT genes =", len(mt_genes))

# 2. gene -> transcripts
sym2tx = {}
for r in csv.DictReader(open(REF, encoding="utf-8", errors="replace"), delimiter="\t"):
    g = (r["gene_name"] or "").strip()
    if g in nuc_genes or g in mt_genes:
        sym2tx.setdefault(g, []).append(r["transcript_id"])

# 3. per-sample expression
with gzip.open(PAM, "rt", encoding="utf-8", errors="replace") as f:
    rd = csv.reader(f, delimiter="\t")
    header = next(rd)
    rows = {r[0]: np.array([float(x) for x in r[1:]]) for r in rd if r}
cols = header[1:]
MOCK = ["PAM_Mock_3","PAM_Mock_4","PAM_Mock_6","PAM_Mock_7"]
INF = ["PAM_134_3","PAM_134_4","PAM_134_6","PAM_134_7",
       "PAM_174_3","PAM_174_4","PAM_174_6","PAM_174_7"]
idx = {c:i for i,c in enumerate(cols)}

def sample_module_score(genes):
    """per-sample mean log2 expression, gene-averaged (transcripts->gene->mean across genes)"""
    per_gene = []
    for g in genes:
        tx = [t for t in sym2tx.get(g,[]) if t in rows]
        if not tx: 
            continue
        gexpr = np.mean([rows[t] for t in tx], axis=0)   # transcript mean per gene
        per_gene.append(gexpr)
    if not per_gene: return None
    return np.mean(per_gene, axis=0)                     # mean across genes per sample

sn = sample_module_score(nuc_genes)
sm = sample_module_score(mt_genes)
print("nuclear genes matched:", sum(1 for g in nuc_genes if any(t in rows for t in sym2tx.get(g,[]))), "/", len(nuc_genes))
print("MT genes matched:", sum(1 for g in mt_genes if any(t in rows for t in sym2tx.get(g,[]))), "/", len(mt_genes))

def ttest_2samp(a, b):
    t, p = stats.ttest_ind(a, b, equal_var=False)
    d = np.mean(a)-np.mean(b)
    # Welch CI
    se = np.sqrt(np.var(a,ddof=1)/len(a) + np.var(b,ddof=1)/len(b))
    df = se**4 / ((np.var(a,ddof=1)/len(a))**2/(len(a)-1) + (np.var(b,ddof=1)/len(b))**2/(len(b)-1))
    lo, hi = d - stats.t.ppf(0.975,df)*se, d + stats.t.ppf(0.975,df)*se
    return d, lo, hi, p, t, df

def mw(a,b):
    u,p = stats.mannwhitneyu(a,b,alternative="two-sided")
    return p, 2*u/(len(a)*len(b))-1

print("\n=== 样本级模块分数（mean log2 expr per sample）===")
mi = [idx[c] for c in MOCK]; pi = [idx[c] for c in INF]
for name, sc in [("Nuclear-encoded OXPHOS (n=70)", sn), ("Mitochondrially encoded (n=13)", sm)]:
    mockv = sc[mi]; infv = sc[pi]
    d,lo,hi,p,t,df = ttest_2samp(infv, mockv)   # infected - mock
    pmw, rrb = mw(infv, mockv)
    print("  %-32s mock=%.4f  inf=%.4f  Δ(inf-mock)=%+.4f  95%%CI[%+.4f,%+.4f]  Welch-t p=%.4g  MW p=%.4g"
          % (name, mockv.mean(), infv.mean(), d, lo, hi, p, pmw))

# 区室交互：每样本 D = nuclear - MT，检验 mock vs infected
print("\n=== 区室交互（replicate-aware）：每样本 D = nuclear_score - MT_score ===")
D_mock = sn[mi] - sm[mi]
D_inf  = sn[pi] - sm[pi]
d,lo,hi,p,t,df = ttest_2samp(D_inf, D_mock)
print("  D(mock)=%.4f  D(inf)=%.4f  ΔD=%+.4f  95%%CI[%+.4f,%+.4f]  Welch-t p=%.4g  (df=%.1f)"
      % (D_mock.mean(), D_inf.mean(), d, lo, hi, p, df))
# 配对内部方向：nuclear 与 MT 各自在感染后是否下降
print("\n  单侧/双侧口径：核与 MT 各自感染后变化方向")
for name, sc in [("Nuclear", sn), ("MT", sm)]:
    mockv=sc[mi]; infv=sc[pi]
    print("    %-8s mock=%.4f inf=%.4f  Δ=%+.4f  (下降=%s)" % (name, mockv.mean(), infv.mean(), infv.mean()-mockv.mean(), "是" if infv.mean()<mockv.mean() else "否"))
print("\n  → 原 gene-wise Mann-Whitney 结论（核比 MT 更降）在样本级 = 核 Δ %+.4f vs MT Δ %+.4f" % (sn[pi].mean()-sn[mi].mean(), sm[pi].mean()-sm[mi].mean()))
