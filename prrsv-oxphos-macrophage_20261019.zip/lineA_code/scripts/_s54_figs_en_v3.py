# -*- coding: utf-8 -*-
"""Line A - four main figures, English-labelled version.  v3 (2026-09-30).

v3.1 (2026-10-19) Fig4B label fix: leader lines no longer run through the
       module labels — line start moved just left of the text and every label
       gets a white halo (path_effects.withStroke, zorder 5) that masks any
       crossing line. Original 0930 PNG kept as *.png.bak-20261019.

v3 changes (on top of v2; v2 and the pre-0930 generation are kept in
figs_en/_pre0930_backup/):

NEW-01 Fig2 rebuilt to the specification given by the manuscript legend,
       "Figure 2. Cell-intrinsic suppression of nuclear-encoded OXPHOS and
       elevation of mitochondrially encoded subunits":
         (A) module-score distributions for nuclear-encoded OXPHOS (left) and
             the mitochondrially encoded subunits (right) in viral-positive and
             viral-negative macrophages from representative libraries, with the
             pooled age-matched uninfected control distribution for reference;
         (B) per-library effect sizes for all EIGHT modules in the intrinsic
             comparison, each point one library, horizontal bar = group mean,
             modules ordered by mean effect size;
         (C) per-group effect sizes for the two core modules across the four
             evaluable strain-and-time-point groups, number of libraries in
             brackets.
       The previous Fig2 showed nuclear-encoded OXPHOS only (boxplot + two
       per-library forests), which the legend and the in-text citation
       "(Figure 2A, B)" / "(Figure 2C)" did not describe.
       Group means reproduced here match the body text digit for digit:
       OXNUC -0.5134 / -0.5214 / -0.4863 / -0.0526 and
       MT    +0.4505 / +0.4910 / +0.3392 / +0.2923 (n = 3 libraries each).

NEW-02 Fig3: the two-line title is moved from the top of the axes to the foot of
       the figure (below the x-axis label), as requested.

Everything else is v2, unchanged:
  FIX-01 terminology | FIX-02/03 Fig1A spans and depth range | FIX-04 Fig1B
  FIX-05 Fig2A wording (now inside the rebuilt panel A) | FIX-09 Fig3 12-library
  B axis + BH | FIX-10/11/12 Fig3 quadrant labels and title | FIX-13 Fig3
  filename | FIX-14 Fig4B label slots | FIX-15 MODS MT label | FIX-16 Fig4B
  filled/open encoding | FIX-18 Fig3 legend instead of leaders.

Data of record: _final_counts.csv / _final_A.csv / _final_B.csv /
_final_summary.csv / _final_depthmatch.csv / _thr_sens.csv
"""
import gzip, os
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mp
import matplotlib.patheffects as pe
from matplotlib.lines import Line2D

plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = ["Arial", "Helvetica", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 110
plt.rcParams["savefig.dpi"] = 300
plt.rcParams["axes.linewidth"] = 0.9
plt.rcParams["mathtext.fontset"] = "custom"
plt.rcParams["mathtext.rm"] = "Arial"
plt.rcParams["mathtext.it"] = "Arial:italic"
plt.rcParams["mathtext.bf"] = "Arial:bold"
plt.rcParams["mathtext.default"] = "regular"

D = r"F:\Work Buudy\线A_分析"
QC = os.path.join(D, "GSE247257", "qc")
OUT = os.path.join(D, "figs_en")
os.makedirs(OUT, exist_ok=True)

MODS = [("OXNUC", "Nuclear-encoded OXPHOS"), ("MT", "MT-encoded OXPHOS (13 genes)"),
        ("CII", "Complex II (3/4)"), ("TCA", "TCA cycle"),
        ("FAO", "Fatty acid oxidation (FAO)"), ("MITOR", "Mitoribosome"),
        ("BIOG", "mtDNA maintenance"), ("ISG", "Antiviral / ISG")]
MODNAME = dict(MODS)
COL = {"JA142": "#C0392B", "M8": "#E67E22", "PJ10": "#2471A3", "Negative": "#7F8C8D"}
CMOD = {"OXNUC": "#C0392B", "MT": "#2471A3", "CII": "#E67E22", "TCA": "#8E44AD",
        "FAO": "#16A085", "MITOR": "#2C3E50", "BIOG": "#7F8C8D", "ISG": "#D35400"}

MINUS = "\u2212"


def readcsv(p, sep="\t"):
    rows = []
    with open(p, encoding="utf-8") as f:
        h = f.readline().rstrip("\n").split(sep)
        for ln in f:
            p2 = ln.rstrip("\n").split(sep)
            if len(p2) == len(h):
                rows.append(dict(zip(h, p2)))
    return rows


CO = readcsv(os.path.join(D, "_final_counts.csv"), ",")
RA = readcsv(os.path.join(D, "_final_A.csv"), ",")
RB = readcsv(os.path.join(D, "_final_B.csv"), ",")
SU = readcsv(os.path.join(D, "_final_summary.csv"), ",")
DM = readcsv(os.path.join(D, "_final_depthmatch.csv"), ",")
SUd = {r["module"]: r for r in SU}

DPIS = ["3d", "7d", "14d", "21d"]
INF_ORDER = [("JA142", "3d"), ("JA142", "7d"), ("JA142", "14d"), ("JA142", "21d"),
             ("M8", "3d"), ("M8", "7d"), ("PJ10", "3d"), ("PJ10", "7d")]
VERIFIED = set(r["gsm"] for r in RA)          # 12 infection-confirmed samples

_PC = {}


def percell(gsm):
    if gsm in _PC:
        return _PC[gsm]
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ix = {h: i for i, h in enumerate(hdr)}
        rows = [ln.rstrip("\n").split("\t") for ln in f]
    d = {"nUMI": np.array([float(r[ix["nUMI"]]) for r in rows]),
         "vir": np.array([float(r[ix["virAll"]]) for r in rows]),
         "Mpos": np.array([int(r[ix["Mpos"]]) for r in rows])}
    for k, _ in MODS:
        d[k] = np.array([float(r[ix["sum_" + k]]) for r in rows])
    d["host"] = np.maximum(d["nUMI"] - d["vir"], 1.0)
    d["hmito"] = d["MT"] / d["host"] * 100.0
    d["gate"] = (d["Mpos"] >= 1) & (d["hmito"] <= 15)
    _PC[gsm] = d
    return d


def score(d, k):
    return np.log1p(d[k] / d["host"] * 1e4)


def runs_of(idx):
    out, s, prev = [], idx[0], idx[0]
    for i in idx[1:]:
        if i == prev + 1:
            prev = i
        else:
            out.append((s, prev)); s = prev = i
    out.append((s, prev))
    return out


def bh_q(ps):
    ps = np.asarray(ps, float)
    n = len(ps)
    order = np.argsort(ps)
    q = np.empty(n)
    prev = 1.0
    for i in range(n - 1, -1, -1):
        j = order[i]
        v = ps[j] * n / (i + 1)
        prev = min(prev, v)
        q[j] = prev
    return q


def partition_stats():
    mods = [k for k, _ in MODS]
    A = np.array([float(SUd[k]["A_mean_r"]) for k in mods])
    Ap = np.array([float(SUd[k]["A_p"]) for k in mods])
    Bv, Bp = [], []
    for k in mods:
        v = np.array([float(r["r"]) for r in RB if r["module"] == k and r["gsm"] in VERIFIED])
        Bv.append(v.mean())
        Bp.append(stats.ttest_1samp(v, 0.0)[1])
    Bv = np.array(Bv); Bp = np.array(Bp)
    Aq, Bq = bh_q(Ap), bh_q(Bp)
    tier = []
    for i in range(len(mods)):
        sa, sb = Aq[i] < 0.05, Bq[i] < 0.05
        tier.append("dual" if (sa and sb) else
                    ("micro" if sb else ("intrinsic" if sa else "none")))
    return mods, A, Ap, Aq, Bv, Bp, Bq, tier


# ============================== Fig 1 ==============================
def fig1():
    fig, ax = plt.subplots(1, 3, figsize=(15.6, 4.7))

    a = ax[0]
    y = [int(r["n_gate"]) for r in CO]
    cs = [COL[r["strain"]] for r in CO]
    a.bar(range(len(CO)), y, color=cs, width=0.78)
    a.set_yscale("log"); a.set_ylim(1.5e3, 9e4)
    a.set_ylabel("Gated macrophages (log10)")
    a.set_xlabel("Sample (n = 36)")
    a.set_title("A | Gated macrophage yield\nHatched bars = 3 dpi low-depth batch\n"
                "(median host nUMI 400\u2013500)", fontsize=10.5)
    a.set_xticks([])
    lo_idx = [i for i, r in enumerate(CO) if float(r["host_numi_med"]) < 1500]
    if lo_idx:
        rs = runs_of(lo_idx)
        for i0, i1 in rs:
            a.axvspan(i0 - 0.5, i1 + 0.5, color="#95A5A6", alpha=0.16, zorder=0)
        for i in lo_idx:
            a.bar([i], [y[i]], color="none", edgecolor="#5D6D7E",
                  hatch="////", lw=0.0, width=0.78, zorder=2)
        tgt = (rs[-1][0] + rs[-1][1]) / 2.0
        a.annotate("3 dpi low-depth batch (n = 5)\nJA142 (2) and M8 (3)\nmedian host nUMI 400\u2013500",
                   xy=(tgt, y[int(tgt)] * 1.18), xytext=(20.2, 6.6e4),
                   fontsize=7.4, ha="left", va="top", color="#34495E",
                   arrowprops=dict(arrowstyle="->", color="#5D6D7E", lw=0.9, shrinkB=2))
    a.legend(handles=[mp.Patch(color=COL[k], label=k) for k in ["JA142", "M8", "PJ10", "Negative"]],
             fontsize=7.5, frameon=True, framealpha=0.92, ncol=2, loc="lower right", edgecolor="none")
    a.grid(axis="y", alpha=0.25, lw=0.6)

    b = ax[1]
    xs, ys, cs2, lb = [], [], [], []
    for st, dp in INF_ORDER:
        for r in CO:
            if r["strain"] == st and r["dpi"] == dp:
                m = max(int(r["n_gate"]), 1)
                xs.append(len(xs)); ys.append(int(r["n_pos"]) / m * 1000)
                cs2.append(COL[st]); lb.append(f"{st} {dp}")
    b.bar(range(len(xs)), ys, color=cs2, width=0.8)
    b.set_ylim(0, 158)
    b.set_ylabel("Infection rate (viral+ / gated cells \u00d7 1000)")
    b.set_xlabel("Infected samples (strain \u00d7 time point; 3 animals each)")
    b.set_title("B | Single-cell infection rate\nHighest in one JA142 7 dpi sample\n"
                "(other 2 at 6.3\u20136.8/1000); near zero in M8", fontsize=10.5)
    b.set_xticks(range(0, len(xs), 3))
    b.set_xticklabels([lb[i] for i in range(0, len(lb), 3)], fontsize=7, rotation=45, ha="right")
    b.grid(axis="y", alpha=0.25, lw=0.6)

    c = ax[2]
    c.bar(range(len(CO)), [np.log1p(int(r["vir_max"])) for r in CO],
          color=[COL[r["strain"]] for r in CO], width=0.78)
    c.set_ylim(0, 11.6)
    c.set_ylabel("Maximum viral UMI per sample (log1p)")
    c.set_xlabel("Sample (n = 36)")
    c.set_title("C | Upper bound of viral detection\nZero in all 12 uninfected controls\n"
                "(specificity evidence)", fontsize=10.5)
    c.set_xticks([])
    idx_neg = [i for i, r in enumerate(CO) if r["strain"] == "Negative"]
    c.plot(idx_neg, [0.06] * len(idx_neg), "v", color="#2C3E50", ms=4)
    c.text(1.0, 10.4, "Viral (\u22651) cells = 0 in all 12 uninfected controls", fontsize=8.8, color="#1B4F72")
    c.grid(axis="y", alpha=0.25, lw=0.6)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "Fig1_gating_and_infection_rate.png"), bbox_inches="tight")
    plt.close(fig)


# ============================== Fig 2 (rebuilt, v3) ==============================
def fig2():
    fig = plt.figure(figsize=(17.4, 5.4))
    gs = fig.add_gridspec(1, 3, width_ratios=[2.30, 1.55, 1.15], wspace=0.42)
    gsA = gs[0, 0].subgridspec(1, 2, wspace=0.28)
    a1 = fig.add_subplot(gsA[0, 0])
    a2 = fig.add_subplot(gsA[0, 1])

    # ---- A: distributions for the two core compartments ----
    reps = [("GSM7886199", "JA142 7d", "#16"), ("GSM7886197", "PJ10 3d", "#32")]
    for axx, mod, ttl, ylab in [
            (a1, "OXNUC", "A | Nuclear-encoded OXPHOS",
             "Module score\nlog1p(module UMI / host nUMI $\\times$ 10$^4$)"),
            (a2, "MT", "A | MT-encoded OXPHOS (13 genes)", "Module score")]:
        data, labs, cols = [], [], []
        for g, nm, tag in reps:
            d = percell(g); s = score(d, mod)
            st, dp = nm.split()
            data.append(s[d["gate"] & (d["vir"] >= 10)]); labs.append(f"{st}\n{dp}\n{tag} viral+"); cols.append("#C0392B")
            data.append(s[d["gate"] & (d["vir"] == 0)]); labs.append(f"{st}\n{dp}\n{tag} viral-"); cols.append("#F1948A")
        ctrl = []
        for cc in ["GSM7886187", "GSM7886191", "GSM7886195"]:
            d = percell(cc); ctrl.append(score(d, mod)[d["gate"]])
        data.append(np.concatenate(ctrl)); labs.append("Uninfected\n(3 dpi)"); cols.append("#7F8C8D")
        bp = axx.boxplot(data, patch_artist=True, widths=0.6, showfliers=False,
                         medianprops=dict(color="black", lw=1.2))
        for p, cc in zip(bp["boxes"], cols):
            p.set_facecolor(cc); p.set_alpha(0.78); p.set_edgecolor("black"); p.set_linewidth(0.8)
        axx.set_xticklabels(labs, fontsize=6.8)
        axx.set_ylabel(ylab, fontsize=8.0)
        axx.set_title(ttl, fontsize=9.5)
        axx.grid(axis="y", alpha=0.25, lw=0.6)

    # ---- B: per-library effect sizes for all eight modules (comparison A) ----
    b = fig.add_subplot(gs[0, 1])
    per = {}
    for k, _ in MODS:
        per[k] = [(float(r["r"]), r["strain"]) for r in RA
                  if r["module"] == k and r["gsm"] in VERIFIED]
    order = sorted([k for k, _ in MODS], key=lambda k: np.mean([x for x, _ in per[k]]))
    b.axvline(0, color="black", lw=0.9, zorder=1)
    for i, k in enumerate(order):
        vals = [x for x, _ in per[k]]
        strs = [s for _, s in per[k]]
        b.scatter(vals, [i] * len(vals), c=[COL[s] for s in strs], s=26,
                  edgecolors="none", alpha=0.9, zorder=3)
        m = float(np.mean(vals))
        b.plot([0, m], [i, i], color="black", lw=2.0, solid_capstyle="butt", zorder=2)
        b.plot([m], [i], "|", color="black", ms=11, mew=1.6, zorder=4)
    # short axis labels so the tick column cannot overhang into panel A
    SHORT = {"OXNUC": "Nuclear OXPHOS", "MT": "MT-encoded OXPHOS", "CII": "Complex II (3/4)",
             "TCA": "TCA cycle", "FAO": "Fatty acid oxidation", "MITOR": "Mitoribosome",
             "BIOG": "mtDNA maintenance", "ISG": "Antiviral / ISG"}
    b.set_yticks(range(len(order)))
    b.set_yticklabels([SHORT[k] for k in order], fontsize=7.6)
    b.set_ylim(-0.7, len(order) - 0.3)
    b.set_xlim(-0.85, 0.70)
    b.set_xlabel("rank-biserial r (negative = lower in viral+)", fontsize=8.8)
    b.set_title("B | Per-library effect sizes, comparison A\n"
                "bar = mean across the 12 libraries; modules ordered by mean", fontsize=9.5)
    b.grid(axis="x", alpha=0.25, lw=0.6)
    b.legend(handles=[Line2D([], [], ls="none", marker="o", ms=5.5, mfc=COL[s], mec="none", label=s)
                      for s in ["JA142", "M8", "PJ10"]],
             fontsize=7.2, frameon=False, loc="lower right", ncol=3, handletextpad=0.25,
             columnspacing=0.9, borderaxespad=0.35)

    # ---- C: per-group effect sizes for the two core compartments ----
    c = fig.add_subplot(gs[0, 2])
    GROUPS = [("JA142", "7d", "JA142\n7 dpi"), ("PJ10", "3d", "PJ10\n3 dpi"),
              ("PJ10", "7d", "PJ10\n7 dpi"), ("JA142", "14d", "JA142\n14 dpi")]
    c.axhline(0, color="black", lw=0.9, zorder=1)
    ns = [0] * len(GROUPS)
    for mod in ["OXNUC", "MT"]:
        means = []
        for i, (st, dp, _) in enumerate(GROUPS):
            v = [float(r["r"]) for r in RA if r["module"] == mod
                 and r["strain"] == st and r["dpi"] == dp and r["gsm"] in VERIFIED]
            ns[i] = len(v); means.append(float(np.mean(v)))
            c.plot([i] * len(v), v, "_", color=CMOD[mod], ms=7, mew=1.2, alpha=0.5, zorder=2)
        c.plot(range(len(GROUPS)), means, "-o", color=CMOD[mod], lw=1.7, ms=8.5,
               mec="black", mew=0.8, label=MODNAME[mod], zorder=3)
    c.set_xticks(range(len(GROUPS)))
    c.set_xticklabels([f"{t}\n(n = {n})" for (_, _, t), n in zip(GROUPS, ns)], fontsize=7.0)
    c.set_xlim(-0.55, len(GROUPS) - 0.45)
    c.set_ylim(-0.85, 0.72)
    c.set_ylabel("rank-biserial r", fontsize=8.8)
    c.set_xlabel("Strain and time point", fontsize=8.8)
    c.set_title("C | Effect sizes by strain and time point\n"
                "four groups that met the cellularity criterion\n"
                "(thin dashes = individual libraries)", fontsize=9.5)
    c.grid(axis="y", alpha=0.25, lw=0.6)
    c.legend(fontsize=7.6, frameon=True, framealpha=0.92, edgecolor="none",
             loc="upper right", borderaxespad=0.3)

    fig.savefig(os.path.join(OUT, "Fig2_main_finding_nuclear_OXPHOS_2x2.png"), bbox_inches="tight")
    plt.close(fig)


# ============================== Fig 3 ==============================
def fig3():
    mods, A, Ap, Aq, Bv, Bp, Bq, tier = partition_stats()

    fig, ax = plt.subplots(figsize=(8.8, 7.4))

    STY = {"dual":      ("o", None, "black", 1.0, 13.0),
           "micro":     ("o", "white", None, 2.2, 13.0),
           "intrinsic": ("s", None, "black", 1.0, 12.0),
           "none":      ("o", "none", None, 1.0, 13.0)}
    for k, x, y, t in zip(mods, A, Bv, tier):
        mk, mfc, mec, mew, ms = STY[t]
        ax.plot(x, y, mk, ms=ms,
                color=(CMOD[k] if mfc is None else mfc),
                mfc=mfc, mec=(CMOD[k] if mec is None else mec), mew=mew, zorder=3)

    ax.axhline(0, color="black", lw=1.0); ax.axvline(0, color="black", lw=1.0)
    ax.set_xlim(-0.80, 0.84); ax.set_ylim(-0.56, 0.62)

    QT = dict(fontsize=8.6, color="#5D6D7E", style="italic")
    ax.text(-0.790, 0.610, "Down in infected / up in bystander", ha="left", va="top", **QT)
    ax.text(0.835, 0.610, "Up in both", ha="right", va="top", **QT)
    ax.text(-0.790, -0.550, "Down in both", ha="left", va="bottom", **QT)
    ax.text(0.835, -0.550, "Up in infected / down in bystander", ha="right", va="bottom", **QT)

    TIERWORD = {"dual": "dual-component", "micro": "microenvironment-associated",
                "intrinsic": "purely intrinsic", "none": "not significant"}
    order = [k for k in mods if tier[mods.index(k)] == "dual"] + \
            [k for k in mods if tier[mods.index(k)] == "micro"] + \
            [k for k in mods if tier[mods.index(k)] == "intrinsic"] + \
            [k for k in mods if tier[mods.index(k)] == "none"]
    handles, labels = [], []
    for k in order:
        mk, mfc, mec, mew, ms = STY[tier[mods.index(k)]]
        handles.append(Line2D([], [], ls="none", marker=mk, ms=9.0,
                              color=(CMOD[k] if mfc is None else mfc),
                              mfc=mfc, mec=(CMOD[k] if mec is None else mec), mew=mew))
        labels.append(f"{MODNAME[k]} \u2014 {TIERWORD[tier[mods.index(k)]]}")
    ax.legend(handles, labels, fontsize=8.2, frameon=False, loc="upper left",
              bbox_to_anchor=(-0.008, 0.880), labelspacing=0.62, handletextpad=0.7,
              borderaxespad=0.4)
    ax.text(-0.070, -0.300, "Markers for CII and FAO coincide", fontsize=7.4, color="#616A6B",
            style="italic", ha="center", va="top")

    ax.set_xlabel("Comparison A, cell-intrinsic: mean module r, viral+ vs viral\u2212 within sample",
                  fontsize=10)
    ax.set_ylabel("Comparison B, microenvironment-associated: mean module r,\n"
                  "bystanders in infected vs age-matched uninfected animals", fontsize=10)
    ax.grid(alpha=0.22, lw=0.6)

    # NEW-02 : title moved from the top of the axes to the foot of the figure
    # NEW-02 : title moved from the top of the axes to the foot of the figure.
    # The "Fig 3 |" prefix is deliberately omitted: the journal sets the figure
    # number in the layout, so printing it inside the image duplicates it.
    fig.tight_layout()
    fig.subplots_adjust(bottom=0.20)
    fig.text(0.5, 0.012,
             "Modules separate into three tiers by FDR significance on comparison A and B\n"
             "(host denominator; 12 evaluable libraries; BH across the 8 modules)",
             ha="center", va="bottom", fontsize=10.5, linespacing=1.5)
    fig.savefig(os.path.join(OUT, "Fig3_module_partition.png"), bbox_inches="tight")
    plt.close(fig)


# ============================== Fig 4 ==============================
def fig4():
    fig, ax = plt.subplots(1, 2, figsize=(13.4, 5.6))

    a = ax[0]
    p = os.path.join(D, "_thr_sens.csv")
    if os.path.exists(p):
        rows = readcsv(p, ",")
        show = ["OXNUC", "MT", "MITOR", "FAO", "ISG", "BIOG"]
        THR = [2, 5, 10, 20, 50, 100]
        for k in show:
            sub = {int(r["threshold_v"]): r for r in rows if r["module"] == k}
            xs = [t for t in THR if t in sub]
            ys = [float(sub[t]["mean_r"]) for t in xs]
            ns = [int(sub[t]["n_samples"]) for t in xs]
            a.plot(xs, ys, "-o", color=CMOD[k], lw=1.9, ms=6.5, label=MODNAME[k])
            a.annotate(f"n={ns[-1]}", (xs[-1], ys[-1]), textcoords="offset points",
                       xytext=(4, -2), fontsize=7.6, color=CMOD[k])
        a.axhline(0, color="black", lw=1.0)
        a.axvline(10, color="black", ls="--", lw=1.2)
        a.text(10.6, -0.655, "Primary threshold v \u2265 10", fontsize=8.4)
        # (the earlier unlabelled red sweep arrow was removed: it read as a stray data line)
        a.set_xscale("log")
        a.set_xticks(THR); a.set_xticklabels([str(t) for t in THR])
        a.set_ylim(-0.72, 0.82)
        a.set_xlabel("viral+ calling threshold (viral UMI per cell)")
        a.set_ylabel("Comparison A mean module r (intrinsic component)")
        a.set_title("A | Threshold sensitivity (dose response)\n"
                    "Effect strengthens with stringency \u2192 not an ambient RNA artefact",
                    fontsize=10.5)
        a.legend(fontsize=8, frameon=True, framealpha=0.92, edgecolor="none",
                 ncol=2, loc="upper left")
        a.grid(alpha=0.25, lw=0.6)
    else:
        a.text(0.5, 0.5, "Threshold-scan data pending", ha="center", va="center"); a.set_axis_off()

    b = ax[1]
    md = {}
    for r in DM:
        md.setdefault(r["module"], []).append((float(r["crude_delta"]), r["matched_delta"]))
    xs, ys, ks = [], [], []
    for k, _ in MODS:
        if k not in md:
            continue
        cr = np.mean([x for x, _ in md[k]])
        mm = [float(y) for _, y in md[k] if y != ""]
        ys.append(np.mean(mm)); xs.append(cr); ks.append(k)
    lim = max(max(abs(np.array(xs))), max(abs(np.array(ys)))) * 1.5
    b.plot([-lim, lim], [-lim, lim], ls=":", color="grey", lw=1.1)
    b.axhline(0, color="black", lw=0.9); b.axvline(0, color="black", lw=0.9)
    ALL_OFFS = {"MT":    ((-0.645, 0.610), "left", "center"),
                "ISG":   ((-0.645, 0.505), "left", "center"),
                "TCA":   ((-0.645, 0.060), "left", "center"),
                "BIOG":  ((-0.645, -0.030), "left", "center"),
                "MITOR": ((-0.645, -0.120), "left", "center"),
                "CII":   ((-0.645, -0.210), "left", "center"),
                "FAO":   ((-0.645, -0.300), "left", "center"),
                "OXNUC": ((-0.645, -0.395), "left", "center")}
    OFFS = {k: v for k, v in ALL_OFFS.items() if k in ks}
    for k, x, y in zip(ks, xs, ys):
        sig = float(SUd[k]["D_p"]) < 0.05
        b.plot(x, y, "o", ms=12, zorder=3,
               mfc=(CMOD[k] if sig else "white"), mec=(CMOD[k] if not sig else "black"),
               mew=(2.2 if not sig else 1.0), alpha=(0.9 if sig else 1.0))
        (lx, ly), ha, va = OFFS.get(k, ((x + 0.03, y + 0.03), "left", "bottom"))
        # leader line starts at the label anchor; the white halo on the text
        # masks the line wherever it passes behind the label
        b.annotate("", xy=(x, y), xytext=(lx, ly),
                   arrowprops=dict(arrowstyle="-", color=CMOD[k], lw=0.7,
                                   alpha=0.65, shrinkA=0, shrinkB=5), zorder=2)
        # white halo: any line that still crosses the label is masked behind it
        b.text(lx, ly, MODNAME[k], fontsize=8.6, color=CMOD[k], ha=ha, va=va, zorder=5,
               path_effects=[pe.withStroke(linewidth=2.8, foreground="white")])
    b.set_xlim(-lim, lim); b.set_ylim(-lim, lim)
    b.set_xlabel("Unstratified crude delta (viral+ \u2212 viral\u2212; mean within-sample median difference)")
    b.set_ylabel("Depth-matched delta (after host nUMI decile stratification)")
    b.set_title("B | Robustness to sequencing depth (host-denominator scores)\n"
                "Modules fall near y = x \u2192 not a depth artefact\n"
                "Filled symbols = matched estimate still significant (P < 0.05); open = not",
                fontsize=10.5)
    b.grid(alpha=0.22, lw=0.6)

    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "Fig4_robustness_threshold_and_depth.png"), bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig1(); print("fig1 ok")
    fig2(); print("fig2 ok")
    fig3(); print("fig3 ok")
    fig4(); print("fig4 ok")
