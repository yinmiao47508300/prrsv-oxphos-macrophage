# -*- coding: utf-8 -*-
"""主分析：模块打分 + 比较A(viral+ vs viral-, 同动物内) + 比较B(感染组viral- vs 对照)
   主阈值 v>=10；viral- 取 virAll==0（干净旁观）；门控 Mpos>=1 且 pct_mito<=15
   模块得分 = log1p(模块UMI / nUMI * 1e4)  —— 深度已由 CPM 式归一化抵消
"""
import gzip, os, math
import numpy as np
from scipy import stats

QC = r"F:\Work Buudy\线A_分析\GSE247257\qc"
OUT = r"F:\Work Buudy\线A_分析\_step28_main.txt"
lines = []
def log(*a): lines.append(" ".join(str(x) for x in a))

MODS = ["OXNUC", "MT", "CII", "TCA", "FAO", "MITOR", "BIOG", "ISG"]
MLAB = {"OXNUC": "核编码 OXPHOS", "MT": "MT 编码 13 亚基", "CII": "Complex II (3/4)",
        "TCA": "TCA 循环", "FAO": "脂肪酸氧化 FAO", "MITOR": "线粒体核糖体",
        "BIOG": "mtDNA 维持机器", "ISG": "抗病毒/ISG"}

# 样本 -> (毒株, dpi, 动物号)
INF = {
 "GSM7886199": ("JA142", 7, "16"), "GSM7886200": ("JA142", 7, "17"), "GSM7886201": ("JA142", 7, "18"),
 "GSM7886175": ("JA142", 14, "19"), "GSM7886176": ("JA142", 14, "20"), "GSM7886177": ("JA142", 14, "21"),
 "GSM7886196": ("PJ10", 3, "31"), "GSM7886197": ("PJ10", 3, "32"), "GSM7886198": ("PJ10", 3, "33"),
 "GSM7886205": ("PJ10", 7, "34"), "GSM7886206": ("PJ10", 7, "35"), "GSM7886207": ("PJ10", 7, "36"),
}
NEGC = {3: ["GSM7886187", "GSM7886191", "GSM7886195"],
        7: ["GSM7886208", "GSM7886209", "GSM7886210"],
        14: ["GSM7886178", "GSM7886179", "GSM7886180"],
        21: ["GSM7886181", "GSM7886182", "GSM7886183"]}

def load(g):
    with gzip.open(os.path.join(QC, g + "_percell.tsv.gz"), "rt", encoding="utf-8") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        ci = {h: i for i, h in enumerate(hdr)}
        rows = [l.rstrip("\n").split("\t") for l in f if l.strip()]
    cols = {h: np.array([float(r[i]) for r in rows]) for h, i in ci.items() if h != "barcode"}
    return cols

def score(c, mod):
    d = c["nUMI"]
    return np.log1p(c["sum_" + mod] / np.maximum(d, 1) * 1e4)

def rb(u, n1, n2):
    return 2.0 * u / (n1 * n2) - 1.0

# ---------------- 汇总容器 ----------------
log("=" * 112)
log("【比较 A】同一样本内：viral+ (v>=10) vs viral- (v=0)，门控巨噬细胞")
log("=" * 112)
log("效应量 = rank-biserial r（正 = viral+ 高于 viral-）")
log("")
A = {m: [] for m in MODS}
detail = []
for g, (st, dp, ani) in sorted(INF.items(), key=lambda x: (x[1][1], x[1][0], x[1][2])):
    c = load(g)
    gate = (c["Mpos"] >= 1) & (c["pct_mito"] <= 15)
    v = c["virAll"]
    pos = gate & (v >= 10)
    neg = gate & (v == 0)
    n1, n2 = int(pos.sum()), int(neg.sum())
    if n1 < 10 or n2 < 10:
        log("%-13s %-6s %2dd 动物%-3s  viral+=%-5d viral-=%-5d  ** 细胞数不足，跳过 **" % (g, st, dp, ani, n1, n2))
        continue
    log("%-13s %-6s %2dd 动物%-3s  viral+=%-5d viral-=%-5d" % (g, st, dp, ani, n1, n2))
    for m in MODS:
        s = score(c, m)
        a, b = s[pos], s[neg]
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        r = rb(u, n1, n2)
        A[m].append(r)
        detail.append((g, st, dp, ani, m, r, p, float(np.median(a)), float(np.median(b))))
        log("      %-16s r=%+.3f  p=%.2e   viral+中位=%.3f  viral-中位=%.3f" %
            (MLAB[m], r, p, float(np.median(a)), float(np.median(b))))
    log("")

log("=" * 112)
log("【比较 A 汇总】按模块跨 12 个样本（4 个毒株×时点，各 n=3 动物）")
log("=" * 112)
log("%-18s %5s %10s %10s %8s %10s %s" % ("模块","n样本","均值 r","中位 r","同向数","t检验p","判读"))
for m in MODS:
    rs = A[m]
    if not rs:
        log("%-18s %5d  -- 无数据 --" % (MLAB[m], 0)); continue
    arr = np.array(rs)
    t, p = stats.ttest_1samp(arr, 0.0)
    nsame = int((arr > 0).sum()) if arr.mean() > 0 else int((arr < 0).sum())
    judge = "viral+ 显著更低" if (arr.mean() < 0 and p < 0.05) else \
            ("viral+ 显著更高" if (arr.mean() > 0 and p < 0.05) else "无方向性")
    log("%-18s %5d %+10.3f %+10.3f %5d/%d %10.3f %s" %
        (MLAB[m], len(arr), arr.mean(), float(np.median(arr)), nsame, len(arr), p, judge))

log("")
log("=" * 112)
log("【比较 A 分组汇总】按 毒株×时点 分别汇总（每组 n=3 动物）")
log("=" * 112)
log("%-18s %s" % ("模块", "  ".join("%-22s" % ("%s %dd" % (k[0], k[1])) for k in
      sorted({(d[1], d[2]) for d in detail}, key=lambda x: (x[1], x[0])))))
groups = sorted({(d[1], d[2]) for d in detail}, key=lambda x: (x[1], x[0]))
for m in MODS:
    cells = []
    for gk in groups:
        rs = [d[5] for d in detail if d[1] == gk[0] and d[2] == gk[1] and d[4] == m]
        cells.append("%+.3f (n=%d)" % (np.mean(rs), len(rs)) if rs else "-")
    log("%-18s %s" % (MLAB[m], "  ".join("%-22s" % c for c in cells)))

# ---------------- 比较 B ----------------
log("")
log("=" * 112)
log("【比较 B】感染组 viral- 巨噬细胞 vs 同 dpi 阴性对照巨噬细胞（旁分泌检验）")
log("=" * 112)
log("注意：跨样本比较，深度已由 CPM 式归一化；仍报两组 nUMI 中位供判断")
log("")
B = {m: [] for m in MODS}
for g, (st, dp, ani) in sorted(INF.items(), key=lambda x: (x[1][1], x[1][0], x[1][2])):
    c = load(g)
    gate = (c["Mpos"] >= 1) & (c["pct_mito"] <= 15)
    bys = gate & (c["virAll"] == 0)
    if int(bys.sum()) < 20:
        continue
    ctrlmods = []
    for ng in NEGC.get(dp, []):
        cc = load(ng)
        g2 = (cc["Mpos"] >= 1) & (cc["pct_mito"] <= 15)
        ctrlmods.append((cc, g2))
    if not ctrlmods:
        continue
    log("%-13s %-6s %2dd 动物%-3s  感染组viral- n=%-5d (nUMI中位%.0f) | 对照 n=%d (nUMI中位%.0f)" %
        (g, st, dp, ani, int(bys.sum()), float(np.median(c["nUMI"][bys])),
         sum(int(x[1].sum()) for x in ctrlmods),
         float(np.median(np.concatenate([x[0]["nUMI"][x[1]] for x in ctrlmods])))))
    for m in MODS:
        a = score(c, m)[bys]
        b = np.concatenate([score(x[0], m)[x[1]] for x in ctrlmods])
        u, p = stats.mannwhitneyu(a, b, alternative="two-sided")
        r = rb(u, len(a), len(b))
        B[m].append(r)
        log("      %-16s r=%+.3f  p=%.2e   感染组旁观中位=%.3f  对照中位=%.3f" %
            (MLAB[m], r, p, float(np.median(a)), float(np.median(b))))
    log("")

log("=" * 112)
log("【比较 B 汇总】")
log("=" * 112)
log("%-18s %5s %10s %10s %8s %10s %s" % ("模块","n样本","均值 r","中位 r","同向数","t检验p","判读"))
for m in MODS:
    rs = B[m]
    if not rs:
        log("%-18s %5d  -- 无数据 --" % (MLAB[m], 0)); continue
    arr = np.array(rs)
    t, p = stats.ttest_1samp(arr, 0.0)
    nsame = int((arr > 0).sum()) if arr.mean() > 0 else int((arr < 0).sum())
    judge = "旁观显著更低(旁分泌)" if (arr.mean() < 0 and p < 0.05) else \
            ("旁观显著更高" if (arr.mean() > 0 and p < 0.05) else "无差异(支持细胞固有)")
    log("%-18s %5d %+10.3f %+10.3f %5d/%d %10.3f %s" %
        (MLAB[m], len(arr), arr.mean(), float(np.median(arr)), nsame, len(arr), p, judge))

log("")
log("=" * 112)
log("【2×2 判别结论】")
log("=" * 112)
ai = A["OXNUC"]; bi = B["OXNUC"]
ta, pa = stats.ttest_1samp(np.array(ai), 0.0) if ai else (0, 1)
tb, pb = stats.ttest_1samp(np.array(bi), 0.0) if bi else (0, 1)
log("  核编码 OXPHOS：")
log("    比较A（viral+ vs viral-） 均值 r=%+.3f  p=%.3f" % (np.mean(ai) if ai else 0, pa))
log("    比较B（感染组旁观 vs 对照）均值 r=%+.3f  p=%.3f" % (np.mean(bi) if bi else 0, pb))
a_sig = bool(ai) and pa < 0.05 and np.mean(ai) < 0
b_sig = bool(bi) and pb < 0.05 and np.mean(bi) < 0
if a_sig and not b_sig:
    log("    => 落 H1：**固有重编程**（感染细胞自身代谢下降，旁观细胞不受影响）")
elif a_sig and b_sig:
    log("    => 落 H1+H0：**固有 + 旁分泌双成分**")
elif (not a_sig) and b_sig:
    log("    => 落 H0：**旁分泌主导**")
else:
    log("    => 两比较均无显著差异：代谢非感染相关（负结果）")

open(OUT, "w", encoding="utf-8").write("\n".join(lines))
print("OK")
