# -*- coding: utf-8 -*-
"""D4: 深度匹配稳健性检验
目的: 证伪"viral+ 细胞的 MT 编码基因升高(及核编码下降)只是测序深度/组成效应"
方法: 在样内按 nUMI 十分位分层, 仅在层内比较 viral+ 与 viral- 的中位得分,
     再按 viral+ 细胞数加权合并 -> 深度匹配 Δ; 与未分层的 crude Δ 对比。
输出: _step29_depthmatch.txt
"""
import gzip, os, io
import numpy as np
from scipy import stats

QC = r"F:\Work Buudy\线A_分析\GSE247257\qc"
OUT = r"F:\Work Buudy\线A_分析\_step29_depthmatch.txt"

MODS = [("OXNUC", "核编码 OXPHOS"), ("MT", "MT 编码 13 亚基"), ("CII", "复合体 II (3/4)"),
        ("TCA", "TCA 循环"), ("FAO", "脂肪酸氧化 FAO"), ("MITOR", "线粒体核糖体"),
        ("BIOG", "mtDNA 维持机器"), ("ISG", "抗病毒/ISG")]

# 样品设计(GEO 原始 characteristics 逐条核对, 2026-09-23 修正)
META = {
    # JA142 3d: 7886188/789/790 | 7d: 799/800/801 | 14d: 775/776/777 | 21d: 784/785/786
    "GSM7886188": ("JA142", "3d", 13), "GSM7886189": ("JA142", "3d", 14), "GSM7886190": ("JA142", "3d", 15),
    "GSM7886199": ("JA142", "7d", 16), "GSM7886200": ("JA142", "7d", 17), "GSM7886201": ("JA142", "7d", 18),
    "GSM7886175": ("JA142", "14d", 19), "GSM7886176": ("JA142", "14d", 20), "GSM7886177": ("JA142", "14d", 21),
    "GSM7886184": ("JA142", "21d", 22), "GSM7886185": ("JA142", "21d", 23), "GSM7886186": ("JA142", "21d", 24),
    # JB15-N-M8-GN: 3d 792/793/794 | 7d: 802/803/804
    "GSM7886192": ("M8", "3d", 25), "GSM7886193": ("M8", "3d", 26), "GSM7886194": ("M8", "3d", 27),
    "GSM7886202": ("M8", "7d", 28), "GSM7886203": ("M8", "7d", 29), "GSM7886204": ("M8", "7d", 30),
    # JB15-N-PJ10-GN: 3d 796/797/798 | 7d: 805/806/807
    "GSM7886196": ("PJ10", "3d", 31), "GSM7886197": ("PJ10", "3d", 32), "GSM7886198": ("PJ10", "3d", 33),
    "GSM7886205": ("PJ10", "7d", 34), "GSM7886206": ("PJ10", "7d", 35), "GSM7886207": ("PJ10", "7d", 36),
}
# 阴性对照: 3d 787/791/795 | 7d 808/809/810 | 14d 778/779/780 | 21d 781/782/783 (无 viral+ 细胞, 不进本检验)
CONTROL = {
    "3d": ["GSM7886187", "GSM7886191", "GSM7886195"],
    "7d": ["GSM7886208", "GSM7886209", "GSM7886210"],
    "14d": ["GSM7886178", "GSM7886179", "GSM7886180"],
    "21d": ["GSM7886181", "GSM7886182", "GSM7886183"],
}


def load(gsm):
    p = os.path.join(QC, gsm + "_percell.tsv.gz")
    if not os.path.exists(p):
        return None
    with gzip.open(p, "rt") as f:
        hdr = f.readline().rstrip("\n").split("\t")
        idx = {h: i for i, h in enumerate(hdr)}
        rows = [ln.rstrip("\n").split("\t") for ln in f]
    if not rows:
        return None
    a = {}
    a["nUMI"] = np.array([int(r[idx["nUMI"]]) for r in rows], dtype=np.int64)
    a["mito"] = np.array([float(r[idx["pct_mito"]]) for r in rows], dtype=np.float64)
    a["vir"] = np.array([int(r[idx["virAll"]]) for r in rows], dtype=np.int64)
    a["Mpos"] = np.array([int(r[idx["Mpos"]]) for r in rows], dtype=np.int64)
    for key, _ in MODS:
        a[key] = np.array([int(float(r[idx["sum_" + key]])) for r in rows], dtype=np.int64)
    return a


def score(sums, n):
    return np.log1p(sums / np.maximum(n, 1) * 1e4)


def main():
    lines = []
    W = lines.append
    W("=" * 110)
    W("【D4 深度匹配稳健性检验】样内按 nUMI 十分位分层, 层内 viral+ vs viral-")
    W("=" * 110)
    W("说明: 每个样品的 'crude Δ' = 全集比较的 (median viral+ − median viral-)")
    W("      'matched Δ' = 各深度层内 (median viral+ − median viral-) 按 viral+ 细胞数加权平均")
    W("      若 matched Δ 与 crude Δ 同号同量级 -> 排除深度/组成效应")

    per_sample = {}
    for gsm, meta in META.items():
        a = load(gsm)
        if a is None:
            continue
        gate = (a["Mpos"] >= 1) & (a["mito"] <= 15)
        pos = gate & (a["vir"] >= 10)
        neg = gate & (a["vir"] == 0)
        npos, nneg = int(pos.sum()), int(neg.sum())
        if npos < 10 or nneg < 50:
            continue

        sub = gate
        nu = a["nUMI"][sub]
        edges = np.percentile(nu, np.arange(0, 101, 10))
        edges = np.unique(edges)
        if len(edges) < 3:
            continue
        nu_all = a["nUMI"]
        bins = np.digitize(nu_all, edges[1:-1], right=False)

        rec = {"npos": npos, "nneg": nneg, "meta": meta, "bins": {}}
        line_buf = []
        line_buf.append("")
        line_buf.append(f"{gsm}   {meta[0]:>5} {meta[1]:>3} 动物{meta[2]}   "
                        f"viral+ n={npos}  viral- n={nneg}   nUMI 中位 viral+={int(np.median(nu_all[pos]))} "
                        f"viral-={int(np.median(nu_all[neg]))}")

        for key, name in MODS:
            s = score(a[key], a["nUMI"])
            crude = float(np.median(s[pos]) - np.median(s[neg]))
            tsum, tw, k = 0.0, 0.0, 0
            bin_diffs = []
            for b in np.unique(bins):
                mp = pos & (bins == b)
                mn = neg & (bins == b)
                if mp.sum() >= 5 and mn.sum() >= 50:
                    d = float(np.median(s[mp]) - np.median(s[mn]))
                    bin_diffs.append(d)
                    tsum += d * float(mp.sum())
                    tw += float(mp.sum())
                    k += 1
            matched = tsum / tw if tw > 0 else float("nan")
            rec[key] = (crude, matched, k)
            rec["bins"][key] = bin_diffs
            ratio = (matched / crude) if (crude != 0 and not np.isnan(matched)) else float("nan")
            line_buf.append(f"      {name:<18} crude Δ={crude:+.4f}   matched Δ={matched:+.4f}   "
                            f"层数={k}   比值={ratio:+.2f}")
        per_sample[gsm] = rec
        lines.extend(line_buf)

    # ---- 模块级汇总 ----
    W("")
    W("=" * 110)
    W("【模块级汇总】跨样本(仅含足够 viral+ 细胞的样本)")
    W("=" * 110)
    W(f"{'模块':<18}{'n样本':>6}{'均值 crude Δ':>15}{'均值 matched Δ':>17}{'同向数':>8}"
      f"{'t检验p(matched)':>18}{'判读':>22}")
    summary = {}
    for key, name in MODS:
        cs = [per_sample[g][key][0] for g in per_sample]
        ms = [per_sample[g][key][1] for g in per_sample if not np.isnan(per_sample[g][key][1])]
        if not ms:
            continue
        mc = float(np.mean(cs))
        mm = float(np.mean(ms))
        conc = sum(1 for x in ms if np.sign(x) == np.sign(mm))
        if len(ms) >= 3:
            t, p = stats.ttest_1samp(np.array(ms), 0.0)
            p = float(p)
        else:
            p = float("nan")
        if p < 0.05 and mm > 0:
            verdict = "深度匹配后仍升高"
        elif p < 0.05 and mm < 0:
            verdict = "深度匹配后仍降低"
        else:
            verdict = "深度匹配后无方向"
        summary[key] = (len(ms), mc, mm, conc, p)
        W(f"{name:<18}{len(ms):>6}{mc:>+15.4f}{mm:>+17.4f}{conc:>5}/{len(ms):<3}{p:>18.4f}{verdict:>22}")

    W("")
    W("判读规则: matched Δ 与 crude Δ 同号且量级接近 -> 该模块效应非深度伪影。")
    W("          matched Δ 显著缩小或变号 -> 该模块效应主要由深度/组成差异驱动, 正文须降级。")

    with io.open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    # ---- CSV 输出(供绘图与复核) ----
    import csv as _csv
    d = os.path.dirname(OUT)
    with io.open(os.path.join(d, "_depthmatch_persample.csv"), "w", encoding="utf-8", newline="") as f:
        w = _csv.writer(f)
        w.writerow(["gsm", "strain", "dpi", "module", "crude_delta", "matched_delta", "n_bins"])
        for g, rec in per_sample.items():
            for key, _ in MODS:
                c, m, k = rec[key]
                w.writerow([g, rec["meta"][0], rec["meta"][1], key, f"{c:.6f}",
                            ("" if np.isnan(m) else f"{m:.6f}"), k])
    with io.open(os.path.join(d, "_depthmatch_summary.csv"), "w", encoding="utf-8", newline="") as f:
        w = _csv.writer(f)
        w.writerow(["module", "n_samples", "mean_crude_delta", "mean_matched_delta", "concordant", "p_matched"])
        for key, _ in MODS:
            if key not in summary:
                continue
            n, mc, mm, conc, p = summary[key]
            w.writerow([key, n, f"{mc:.6f}", f"{mm:.6f}", conc, f"{p:.6f}"])
    print("done")


if __name__ == "__main__":
    main()
